/**
 * Zonefall — server
 * -----------------------------------------------------------------------
 * One Node process does three jobs:
 *   1. Serves the static client (public/) with Express.
 *   2. Handles account registration / login over a tiny JSON REST API,
 *      with scrypt password hashing and random session tokens — no
 *      external auth service, no JWT library, nothing to configure.
 *   3. Runs the realtime match logic over Socket.io: rooms (private,
 *      joined by a 5-character code), the shrinking safe zone, and
 *      server-authoritative health / damage / pickups.
 *
 * Trust model (read this before you extend it):
 *   - Each client simulates its own movement and reports its position
 *     ~10x/second. The server relays that to roommates and uses it for
 *     zone-damage checks, but does not re-simulate physics itself.
 *   - Each client also does its own shot raycasting (simplest way to get
 *     responsive hit-registration in a browser) and reports "I hit
 *     player X with weapon Y in location Z". The server does NOT trust
 *     the damage number from the client — it looks up damage from
 *     WEAPON_STATS itself, checks a basic fire-rate cooldown, and is the
 *     only thing that ever writes to a player's hp.
 *   - This is the right tradeoff for a small game played with friends:
 *     simple, fast, and good enough. It is not cheat-proof against a
 *     determined, modified client. See README.md "Notes on fairness".
 */
'use strict';

const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { Server } = require('socket.io');

const mapLayout = require('./public/shared/mapLayout.json');

const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

const MAX_ROOM_SIZE = 10;
const MIN_PLAYERS_TO_START = 1;
const MATCH_COUNTDOWN_SEC = 5;
const ZONE_TICK_MS = 1000;
const BACK_TO_LOBBY_DELAY_MS = 9000;

const WEAPON_STATS = {
  pistol: { damage: 18, headMultiplier: 2, fireIntervalMs: 330, pellets: 1 },
  rifle: { damage: 22, headMultiplier: 1.8, fireIntervalMs: 130, pellets: 1 },
  shotgun: { damage: 12, headMultiplier: 1.5, fireIntervalMs: 850, pellets: 6 }
};

// ============================== persistence ===============================

function ensureDataFile() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, '{}');
}
function loadUsers() {
  ensureDataFile();
  try {
    return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8') || '{}');
  } catch (err) {
    console.error('[zonefall] could not parse users.json, starting empty:', err.message);
    return {};
  }
}
function saveUsers(users) {
  ensureDataFile();
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}
let users = loadUsers();

// ============================ password hashing =============================
// Node's built-in crypto.scrypt — no extra dependency, no native build step.

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const parts = (stored || '').split(':');
  if (parts.length !== 2) return false;
  const [salt, hashHex] = parts;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, salt, 64);
  if (expected.length !== actual.length) return false;
  return crypto.timingSafeEqual(expected, actual);
}

// ================================ sessions ==================================
// Plain random tokens kept in memory. Simple to reason about, easy to revoke.
// Server restarts clear sessions — players just log in again.

const sessions = new Map(); // token -> { username, expiresAt }
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

function createSession(username) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { username, expiresAt: Date.now() + SESSION_TTL_MS });
  return token;
}
function getSession(token) {
  if (!token) return null;
  const s = sessions.get(token);
  if (!s) return null;
  if (Date.now() > s.expiresAt) { sessions.delete(token); return null; }
  return s;
}

// =============================== validation ================================

const USERNAME_RE = /^[a-zA-Z0-9_]{3,16}$/;
const validUsername = (u) => typeof u === 'string' && USERNAME_RE.test(u);
const validPassword = (p) => typeof p === 'string' && p.length >= 6 && p.length <= 72;

// naive per-IP rate limiting for the auth endpoints
const attempts = new Map();
const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX = 15;
function isRateLimited(ip) {
  const now = Date.now();
  let rec = attempts.get(ip);
  if (!rec || now > rec.resetAt) {
    rec = { count: 0, resetAt: now + RATE_LIMIT_WINDOW_MS };
    attempts.set(ip, rec);
  }
  rec.count++;
  return rec.count > RATE_LIMIT_MAX;
}
setInterval(() => {
  const now = Date.now();
  for (const [ip, rec] of attempts) if (now > rec.resetAt) attempts.delete(ip);
}, 5 * 60 * 1000).unref();

// =================================== HTTP ===================================

const app = express();
app.set('trust proxy', true); // Render sits behind a proxy; needed for correct req.ip
app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/healthz', (req, res) => res.status(200).send('ok'));

app.post('/api/register', (req, res) => {
  if (isRateLimited(req.ip)) {
    return res.status(429).json({ error: 'Too many attempts. Wait a minute and try again.' });
  }
  const { username, password } = req.body || {};
  if (!validUsername(username)) {
    return res.status(400).json({ error: 'Callsign must be 3-16 characters: letters, numbers, underscore.' });
  }
  if (!validPassword(password)) {
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  }
  const key = username.toLowerCase();
  if (users[key]) {
    return res.status(409).json({ error: 'That callsign is already taken.' });
  }
  users[key] = { username, passwordHash: hashPassword(password), createdAt: Date.now() };
  saveUsers(users);
  const token = createSession(users[key].username);
  res.json({ token, username: users[key].username });
});

app.post('/api/login', (req, res) => {
  if (isRateLimited(req.ip)) {
    return res.status(429).json({ error: 'Too many attempts. Wait a minute and try again.' });
  }
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: 'Callsign and password are required.' });
  }
  const user = users[username.toLowerCase()];
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Incorrect callsign or password.' });
  }
  const token = createSession(user.username);
  res.json({ token, username: user.username });
});

app.get('/api/me', (req, res) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const session = getSession(token);
  if (!session) return res.status(401).json({ error: 'Not logged in.' });
  res.json({ username: session.username });
});

app.post('/api/logout', (req, res) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  sessions.delete(token);
  res.json({ ok: true });
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// ================================ game state ================================

const rooms = new Map(); // code -> room

const ROOM_CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // no 0/O/1/I/L — easy to read aloud
function generateRoomCode() {
  let code;
  do {
    code = '';
    for (let i = 0; i < 5; i++) code += ROOM_CODE_CHARS[Math.floor(Math.random() * ROOM_CODE_CHARS.length)];
  } while (rooms.has(code));
  return code;
}

function createRoomState(code, hostSocketId, options = {}) {
  return {
    code,
    hostId: hostSocketId,
    status: 'lobby', // lobby | starting | active | ended
    players: new Map(), // socketId/botId -> playerState
    botCount: Number(options.botCount) || 0,
    teamMode: !!options.teamMode,
    teamConfig: options.teamConfig || null,
    botTimer: null,
    pickups: new Map(), // id -> { type, x, z, active }
    zone: {
      center: mapLayout.zone.center,
      radius: mapLayout.zone.initialRadius,
      targetRadius: mapLayout.zone.initialRadius,
      phaseIndex: -1,
      phaseStartedAt: 0
    },
    tickTimer: null,
    matchStartedAt: 0,
    playersAtStart: 0
  };
}

function newPlayerState(username, isBot = false, team = null) {
  return {
    username, isBot, team, x: 0, y: 0, z: 0, ry: 0,
    hp: 100, alive: true, kills: 0, placement: null,
    weapon: 'pistol', lastShotAt: {}
  };
}
function addRoomBots(room, countOrTeams) {
  const list = room.teamMode
    ? [['A', Number(countOrTeams?.A) || 0], ['B', Number(countOrTeams?.B) || 0]]
    : [[null, Math.max(0, Math.min(MAX_ROOM_SIZE - 1, Number(countOrTeams) || 0))]];
  let n = 0;
  for (const [team, count] of list) for (let i = 0; i < count && room.players.size < MAX_ROOM_SIZE; i++) {
    const id = `bot:${crypto.randomBytes(5).toString('hex')}`;
    room.players.set(id, newPlayerState(`Bot-${String(++n).padStart(2, '0')}`, true, team));
  }
}
function botHasLineOfSight(a, b) {
  const dx = b.x - a.x, dz = b.z - a.z;
  const len2 = dx * dx + dz * dz;
  if (len2 < 1) return true;
  for (const prop of (mapLayout.props || [])) {
    let radius = 0, height = 2;
    if (prop.type === 'building') { radius = prop.size === 'large' ? 8 : 6; height = 6; }
    else if (prop.type === 'rock') { radius = 2.4 * (prop.scale || 1); height = 2.8 * (prop.scale || 1); }
    else if (prop.type === 'tree') { radius = 1.6 * (prop.scale || 1); height = 5.5 * (prop.scale || 1); }
    else if (prop.type === 'crate') { radius = 1.4; height = 1.8; }
    else continue;
    const px = prop.x - a.x, pz = prop.z - a.z;
    const t = Math.max(0, Math.min(1, (px * dx + pz * dz) / len2));
    if (t < 0.06 || t > 0.94) continue;
    const cx = a.x + dx * t, cz = a.z + dz * t;
    if (Math.hypot(prop.x - cx, prop.z - cz) <= radius) return false;
  }
  return true;
}
function tickBots(room) {
  if (!room || room.status !== 'active') return;
  const bots = Array.from(room.players.entries()).filter(([, p]) => p.isBot && p.alive);
  const living = Array.from(room.players.entries()).filter(([, p]) => p.alive);
  for (const [id, bot] of bots) {
    const targets = living.filter(([targetId, p]) => targetId !== id && p.alive && !p.isBot && (!room.teamMode || p.team !== bot.team));
    if (!targets.length) continue;
    targets.sort((a, b) => Math.hypot(a[1].x - bot.x, a[1].z - bot.z) - Math.hypot(b[1].x - bot.x, b[1].z - bot.z));
    const [targetId, target] = targets[0];
    bot.y = target.y;
    const dx = target.x - bot.x, dz = target.z - bot.z;
    const dist = Math.hypot(dx, dz) || 1;
    bot.ry = Math.atan2(dx, dz);
    const step = Math.min(0.65, Math.max(0, dist - 16));
    bot.x += (dx / dist) * step; bot.z += (dz / dist) * step;
    io.to(room.code).emit('playerMoved', { id, x: bot.x, y: bot.y, z: bot.z, ry: bot.ry, anim: step > 0 ? 'run' : 'idle', weapon: bot.weapon, team: bot.team });
    const now = Date.now();
    const canSee = botHasLineOfSight(bot, target);
    if (dist < 22 && canSee && now - (bot.lastShotAt.pistol || 0) >= 1200 && Math.random() < 0.72) {
      bot.lastShotAt.pistol = now;
      io.to(room.code).emit('shotFired', { id, weapon: 'pistol' });
      applyDamage(room, targetId, 8, id);
    }
  }
}


function publicRoomPlayers(room) {
  return Array.from(room.players.entries()).map(([id, p]) => ({
    id, username: p.username, alive: p.alive, kills: p.kills, hp: p.hp, isHost: id === room.hostId, isBot: !!p.isBot, team: p.team
  }));
}
function broadcastRoomList(room) {
  io.to(room.code).emit('roomPlayers', publicRoomPlayers(room));
}

function resetPickups(room) {
  room.pickups.clear();
  for (const p of mapLayout.pickups) room.pickups.set(p.id, { type: p.type, x: p.x, z: p.z, active: true });
}

function assignSpawns(room) {
  const ids = Array.from(room.players.keys());
  const n = ids.length;
  const ringR = mapLayout.spawnRing.radius;
  ids.forEach((id, i) => {
    const angle = (i / Math.max(n, 1)) * Math.PI * 2 + rand(-0.15, 0.15);
    const p = room.players.get(id);
    p.x = Math.cos(angle) * ringR;
    p.z = Math.sin(angle) * ringR;
    p.y = mapLayout.dropZoneCenter.y;
    p.hp = 100;
    p.alive = true;
    p.kills = 0;
    p.placement = null;
    p.weapon = 'pistol';
    p.lastShotAt = {};
  });
}
function rand(min, max) { return min + Math.random() * (max - min); }

function startMatch(room) {
  if (room.status !== 'lobby') return;
  room.status = 'starting';
  room.playersAtStart = room.players.size;
  assignSpawns(room);
  resetPickups(room);
  room.zone = {
    center: mapLayout.zone.center,
    radius: mapLayout.zone.initialRadius,
    targetRadius: mapLayout.zone.initialRadius,
    phaseIndex: -1,
    phaseStartedAt: 0
  };

  io.to(room.code).emit('matchStarting', {
    countdownSec: MATCH_COUNTDOWN_SEC,
    spawns: Array.from(room.players.entries()).map(([id, p]) => ({ id, x: p.x, y: p.y, z: p.z, isBot: !!p.isBot, team: p.team })),
    pickups: Array.from(room.pickups.entries()).map(([id, p]) => ({ id, type: p.type, x: p.x, z: p.z }))
  });

  setTimeout(() => {
    if (!rooms.has(room.code) || room.status !== 'starting') return;
    room.status = 'active';
    room.matchStartedAt = Date.now();
    if (room.botCount > 0) room.botTimer = setInterval(() => tickBots(room), 250);
    room.zone.phaseIndex = 0;
    room.zone.phaseStartedAt = Date.now();
    io.to(room.code).emit('matchStarted', { startedAt: room.matchStartedAt });
    beginZoneTicking(room);
  }, MATCH_COUNTDOWN_SEC * 1000);
}

function beginZoneTicking(room) {
  if (room.tickTimer) clearInterval(room.tickTimer);
  room.tickTimer = setInterval(() => tickRoom(room), ZONE_TICK_MS);
}

function tickRoom(room) {
  if (room.status !== 'active') return;
  const now = Date.now();
  const z = room.zone;
  const phases = mapLayout.zone.phases;
  let shrinkStartAt = null, shrinkEndAt = null;

  if (z.phaseIndex >= 0 && z.phaseIndex < phases.length) {
    const phase = phases[z.phaseIndex];
    shrinkStartAt = z.phaseStartedAt + phase.waitBeforeSec * 1000;
    shrinkEndAt = shrinkStartAt + phase.shrinkDurationSec * 1000;
    const fromRadius = z.phaseIndex === 0 ? mapLayout.zone.initialRadius : phases[z.phaseIndex - 1].shrinkToRadius;

    if (now < shrinkStartAt) {
      z.radius = fromRadius;
      z.targetRadius = phase.shrinkToRadius;
    } else if (now < shrinkEndAt) {
      const t = (now - shrinkStartAt) / (phase.shrinkDurationSec * 1000);
      z.radius = fromRadius + (phase.shrinkToRadius - fromRadius) * Math.min(Math.max(t, 0), 1);
      z.targetRadius = phase.shrinkToRadius;
    } else {
      z.radius = phase.shrinkToRadius;
      z.targetRadius = phase.shrinkToRadius;
      if (z.phaseIndex + 1 < phases.length) {
        z.phaseIndex += 1;
        z.phaseStartedAt = now;
      }
    }
  }

  io.to(room.code).emit('zoneUpdate', { radius: z.radius, targetRadius: z.targetRadius, phaseIndex: z.phaseIndex, shrinkStartAt, shrinkEndAt });

  const activePhase = phases[Math.min(Math.max(z.phaseIndex, 0), phases.length - 1)];
  const dmgPerSec = activePhase ? activePhase.damagePerSec : 10;
  for (const [id, p] of room.players) {
    if (!p.alive) continue;
    const d = Math.hypot(p.x - z.center.x, p.z - z.center.z);
    if (d > z.radius) applyDamage(room, id, dmgPerSec, 'zone');
  }
}

function applyDamage(room, targetId, amount, sourceId) {
  if (room.status !== 'active') return; // never apply damage to a match that already ended
  const target = room.players.get(targetId);
  if (!target || !target.alive) return;
  target.hp = Math.max(0, Math.round((target.hp - amount) * 10) / 10);
  io.to(room.code).emit('healthUpdate', { id: targetId, hp: target.hp });
  if (target.hp <= 0) eliminatePlayer(room, targetId, sourceId);
}

function eliminatePlayer(room, targetId, sourceId) {
  const target = room.players.get(targetId);
  if (!target || !target.alive) return;
  target.alive = false;
  const aliveCount = Array.from(room.players.values()).filter((p) => p.alive).length;
  target.placement = aliveCount + 1;

  let killerName = null;
  if (sourceId && sourceId !== 'zone' && room.players.has(sourceId)) {
    const killer = room.players.get(sourceId);
    killer.kills += 1;
    killerName = killer.username;
  }

  io.to(room.code).emit('playerEliminated', { id: targetId, username: target.username, by: killerName, placement: target.placement });
  checkWinCondition(room);
}

function checkWinCondition(room) {
  if (room.status !== 'active') return;
  if (room.teamMode) {
    const aliveTeams = new Set(Array.from(room.players.values()).filter((p) => p.alive && p.team).map((p) => p.team));
    if (aliveTeams.size <= 1) {
      const winner = Array.from(room.players.entries()).find(([, p]) => p.alive && p.team === [...aliveTeams][0]);
      endMatch(room, winner ? winner[0] : null);
    }
    return;
  }
  const humans = Array.from(room.players.entries()).filter(([, p]) => !p.isBot);
  const aliveHumans = humans.filter(([, p]) => p.alive);
  if (humans.length <= 1) { if (aliveHumans.length === 0) endMatch(room, null); return; }
  if (aliveHumans.length <= 1) endMatch(room, aliveHumans[0] ? aliveHumans[0][0] : null);
}

function endMatch(room, winnerId) {
  room.status = 'ended';
  if (room.tickTimer) { clearInterval(room.tickTimer); room.tickTimer = null; }
  if (room.botTimer) { clearInterval(room.botTimer); room.botTimer = null; }
  if (winnerId && room.players.has(winnerId)) room.players.get(winnerId).placement = 1;

  const results = Array.from(room.players.entries())
    .map(([id, p]) => ({ id, username: p.username, kills: p.kills, placement: p.placement || 1 }))
    .sort((a, b) => (a.placement || 99) - (b.placement || 99));

  io.to(room.code).emit('matchEnded', { winner: winnerId ? room.players.get(winnerId).username : null, results });

  setTimeout(() => {
    if (!rooms.has(room.code)) return;
    room.status = 'lobby';
    broadcastRoomList(room);
    io.to(room.code).emit('backToLobby');
  }, BACK_TO_LOBBY_DELAY_MS);
}

// ============================== socket.io =================================

io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  const session = getSession(token);
  if (!session) return next(new Error('unauthorized'));
  socket.username = session.username;
  next();
});

io.on('connection', (socket) => {
  let currentRoomCode = null;
  const getRoom = () => (currentRoomCode ? rooms.get(currentRoomCode) : null);

  socket.on('createRoom', (options, cb) => {
    if (typeof options === 'function') { cb = options; options = {}; }
    if (currentRoomCode) return cb && cb({ ok: false, error: 'Already in a room.' });
    const code = generateRoomCode();
    const teamMode = !!(options && options.teamMode);
    const rawTeams = options && options.teams || {};
    const teamConfig = teamMode ? {
      A: { humans: Math.max(1, Math.min(5, Number(rawTeams.A?.humans) || 1)), bots: Math.max(0, Math.min(5, Number(rawTeams.A?.bots) || 0)) },
      B: { humans: Math.max(1, Math.min(5, Number(rawTeams.B?.humans) || 1)), bots: Math.max(0, Math.min(5, Number(rawTeams.B?.bots) || 0)) }
    } : null;
    const botCount = teamMode ? 0 : Math.min(MAX_ROOM_SIZE - 1, Math.max(0, Number(options?.botCount ?? (options?.bots ? 3 : 0)) || 0));
    if (teamMode && teamConfig.A.humans + teamConfig.B.humans + teamConfig.A.bots + teamConfig.B.bots > MAX_ROOM_SIZE) return cb && cb({ ok: false, error: 'Team totals cannot exceed 10 players.' });
    const room = createRoomState(code, socket.id, { botCount, teamMode, teamConfig });
    rooms.set(code, room);
    room.players.set(socket.id, newPlayerState(socket.username, false, teamMode ? 'A' : null));
    addRoomBots(room, teamMode ? { A: teamConfig.A.bots, B: teamConfig.B.bots } : botCount);
    socket.join(code);
    currentRoomCode = code;
    cb && cb({ ok: true, code, hostId: room.hostId, players: publicRoomPlayers(room) });
  });

  socket.on('joinRoom', (data, cb) => {
    const code = (((data && data.code) || '') + '').toUpperCase().trim();
    const room = rooms.get(code);
    if (!room) return cb && cb({ ok: false, error: 'Room not found.' });
    if (room.players.size >= MAX_ROOM_SIZE) return cb && cb({ ok: false, error: 'Room is full.' });
    if (room.status === 'active' || room.status === 'starting') return cb && cb({ ok: false, error: 'Match already in progress.' });

    room.players.set(socket.id, newPlayerState(socket.username));
    socket.join(code);
    currentRoomCode = code;
    broadcastRoomList(room);
    cb && cb({ ok: true, code, hostId: room.hostId, players: publicRoomPlayers(room) });
  });

  socket.on('leaveRoom', () => leaveCurrentRoom());

  function leaveCurrentRoom() {
    const room = getRoom();
    if (!room) return;
    const wasActive = room.status === 'active';
    if (wasActive) eliminatePlayer(room, socket.id, null); // while they are still in the map, so the win check runs
    room.players.delete(socket.id);
    socket.leave(room.code);
    currentRoomCode = null;

    if (room.players.size === 0 || !Array.from(room.players.values()).some((p) => !p.isBot)) {
      if (room.tickTimer) clearInterval(room.tickTimer);
      if (room.botTimer) clearInterval(room.botTimer);
      rooms.delete(room.code);
      return;
    }
    if (room.hostId === socket.id) {
      room.hostId = room.players.keys().next().value;
      io.to(room.code).emit('newHost', { hostId: room.hostId });
    }
    broadcastRoomList(room);
  }

  socket.on('startMatch', () => {
    const room = getRoom();
    if (!room || room.hostId !== socket.id) return;
    if (room.players.size < MIN_PLAYERS_TO_START) return;
    startMatch(room);
  });

  socket.on('chatMessage', (text) => {
    const room = getRoom();
    if (!room || typeof text !== 'string' || !text.trim()) return;
    io.to(room.code).emit('chatMessage', { username: socket.username, text: text.slice(0, 200), at: Date.now() });
  });

  socket.on('playerUpdate', (state) => {
    const room = getRoom();
    if (!room || room.status !== 'active' || !state) return;
    const p = room.players.get(socket.id);
    if (!p || !p.alive) return;
    if (typeof state.x === 'number') p.x = state.x;
    if (typeof state.y === 'number') p.y = state.y;
    if (typeof state.z === 'number') p.z = state.z;
    if (typeof state.ry === 'number') p.ry = state.ry;
    if (typeof state.weapon === 'string') p.weapon = state.weapon;
    socket.to(room.code).emit('playerMoved', { id: socket.id, x: p.x, y: p.y, z: p.z, ry: p.ry, anim: state.anim || 'idle', weapon: p.weapon, team: p.team });
  });

  socket.on('shotFired', () => {
    const room = getRoom();
    if (!room || room.status !== 'active') return;
    const p = room.players.get(socket.id);
    if (!p || !p.alive) return;
    socket.to(room.code).emit('shotFired', { id: socket.id, weapon: p.weapon });
  });

  socket.on('playerHit', (data) => {
    const room = getRoom();
    if (!room || room.status !== 'active' || !data) return;
    const shooter = room.players.get(socket.id);
    if (!shooter || !shooter.alive) return;
    const targetId = data.targetId;
    if (!targetId || targetId === socket.id) return;
    const target = room.players.get(targetId);
    if (!target || !target.alive) return;

    const stats = WEAPON_STATS[data.weaponId];
    if (!stats) return;

    const now = Date.now();
    const last = shooter.lastShotAt[data.weaponId] || 0;
    if (now - last < stats.fireIntervalMs * 0.6) return; // basic fire-rate sanity check
    shooter.lastShotAt[data.weaponId] = now;

    const hits = Math.min(stats.pellets, Math.max(1, Math.floor(Number(data.hits) || 1)));
    const dmg = stats.damage * hits * (data.part === 'head' ? stats.headMultiplier : 1);
    applyDamage(room, targetId, dmg, socket.id);
  });

  socket.on('pickupCollected', (data) => {
    const room = getRoom();
    if (!room || room.status !== 'active' || !data) return;
    const p = room.players.get(socket.id);
    if (!p || !p.alive) return;
    const pickup = room.pickups.get(data.id);
    if (!pickup || !pickup.active) return;
    if (Math.hypot(p.x - pickup.x, p.z - pickup.z) > 6) return; // must actually be near it

    pickup.active = false;
    io.to(room.code).emit('pickupRemoved', { id: data.id });

    if (pickup.type === 'health') {
      p.hp = Math.min(100, p.hp + 50);
      io.to(room.code).emit('healthUpdate', { id: socket.id, hp: p.hp });
    } else {
      p.weapon = pickup.type;
      socket.emit('weaponGranted', { weapon: pickup.type });
    }
  });

  socket.on('disconnect', () => leaveCurrentRoom());
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Zonefall server listening on port ${PORT}`);
});
