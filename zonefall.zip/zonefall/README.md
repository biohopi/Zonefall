# ZONEFALL

An original low-poly, third-person, shrinking-zone shooter you play in the
browser with friends (up to 10 per room). All code, models, sounds and UI are
written from scratch: every 3D object is assembled from Three.js primitives and
every sound is synthesised with WebAudio. No imported assets.

- Phone-first touch controls (joystick, drag-to-look, fire / jump / reload / weapon / sprint). **No gyroscope.**
- Desktop works too: WASD, mouse (click the game to capture it), Shift sprint, Space jump, R reload, Q switch weapon.
- Simple accounts: callsign + password (scrypt-hashed), random session tokens.
- Private rooms with a 5-character code and an invite link.

## Play

1. Create a callsign, then **Create room**.
2. Tap **Copy** and send the invite to friends. They log in and tap **Join**.
3. Host taps **Start match**. Everyone parachutes in. Sprint while falling to dive.
4. Grab weapons (rifle / shotgun) and health from the glowing markers, stay inside the shrinking red zone, be the last one alive.

## Run locally

Needs Node 18+.

    npm install
    npm start

Open http://localhost:3000. For friends on the same Wi-Fi use your computer's LAN address, e.g. http://192.168.1.20:3000.

## Deploy on Render.com

1. Push this folder to a GitHub repo.
2. Render Dashboard > **New > Blueprint** and pick the repo (it reads `render.yaml`).
   Or **New > Web Service** with Build Command `npm install` and Start Command `npm start`.
3. When it is live, share the `https://<name>.onrender.com` URL.

Notes for the free tier:
- The service sleeps after ~15 min idle; the first visit afterwards takes ~30 s to wake up.
- The disk is not persistent: `data/users.json` and sessions reset on every redeploy or restart, so
  players may need to re-register. For permanent accounts attach a Render Disk mounted at `/opt/render/project/src/data`.
- WebSockets work out of the box. The server binds `0.0.0.0` and reads `PORT`.

## Project layout

    server.js                Express + Socket.io: auth, rooms, zone, damage, pickups
    tools/generate-map.js    Writes public/shared/mapLayout.json (islands layout, props, pickups, zone phases)
    public/index.html        All screens
    public/css/style.css     Visual identity
    public/shared/mapLayout.json   Single source of truth shared by server and client
    public/js/
      objectBuilders.js      Every object, built part by part (characters, weapons, trees, rocks, buildings, crates, pickups)
      world.js               Renderer, terrain, instanced props, zone wall, colliders
      players.js             Avatars, remote smoothing, tracers
      controls.js            Touch + keyboard/mouse input
      game.js                Match loop: movement, camera, shooting, HUD feed, network send
      hud.js, audio.js, weapons.js, net.js, main.js

To get a new island: `npm run generate-map` and restart.

## Performance

Flat-shaded Lambert materials, no shadow maps (blob shadows), instanced trees and rocks, fog to hide the far
plane, pixel ratio capped at 1.5. Typical scene is under ~150 draw calls.

## Notes on fairness

Clients simulate their own movement and report hits; the server owns health, damage numbers, fire-rate
limits and pickups. That is plenty for friends, but a modified client could cheat. For a public game you would
make the server simulate movement and hit tests.
