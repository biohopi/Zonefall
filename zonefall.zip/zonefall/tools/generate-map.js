#!/usr/bin/env node
/**
 * Zonefall map generator.
 *
 * Produces public/shared/mapLayout.json — the single source of truth for
 * terrain extent, the shrinking safe zone, prop placement, and pickup /
 * spawn points. Both server.js and the browser client load this exact
 * file, so they can never disagree about where the zone edge or a crate
 * actually is.
 *
 * Re-run any time you want a different island layout:
 *   node tools/generate-map.js
 */
'use strict';
const fs = require('fs');
const path = require('path');

function rand(min, max) { return min + Math.random() * (max - min); }
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function dist(x1, z1, x2, z2) { return Math.hypot(x1 - x2, z1 - z2); }

const TERRAIN_HALF = 170;   // terrain mesh spans -170..170 on both axes
const ISLAND_EDGE = 158;    // beyond this, props give way to open coast

const props = [];

function tooClose(x, z, minGap) {
  for (let i = 0; i < props.length; i++) {
    if (dist(x, z, props[i].x, props[i].z) < minGap) return true;
  }
  return false;
}

function addProp(type, x, z, extra) {
  props.push(Object.assign(
    { type, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10 },
    extra
  ));
}

function scatterTrees(cx, cz, count, radius) {
  let placed = 0, attempts = 0;
  while (placed < count && attempts < count * 10) {
    attempts++;
    const a = rand(0, Math.PI * 2);
    const r = Math.sqrt(Math.random()) * radius;
    const x = cx + Math.cos(a) * r;
    const z = cz + Math.sin(a) * r;
    if (dist(x, z, 0, 0) > ISLAND_EDGE - 6) continue;
    if (tooClose(x, z, 5)) continue;
    addProp('tree', x, z, { scale: +rand(0.8, 1.5).toFixed(2), ry: +rand(0, Math.PI * 2).toFixed(2) });
    placed++;
  }
}

function scatterRocks(cx, cz, count, radius) {
  let placed = 0, attempts = 0;
  while (placed < count && attempts < count * 10) {
    attempts++;
    const a = rand(0, Math.PI * 2);
    const r = Math.sqrt(Math.random()) * radius;
    const x = cx + Math.cos(a) * r;
    const z = cz + Math.sin(a) * r;
    if (dist(x, z, 0, 0) > ISLAND_EDGE - 6) continue;
    if (tooClose(x, z, 4.5)) continue;
    addProp('rock', x, z, { scale: +rand(0.7, 2.1).toFixed(2), ry: +rand(0, Math.PI * 2).toFixed(2) });
    placed++;
  }
}

function addBuilding(x, z, ry, size) {
  addProp('building', x, z, { ry: +ry.toFixed(2), size: size || pick(['small', 'medium', 'large']) });
}

function addCrateProp(x, z) {
  addProp('crate', x, z, { ry: +rand(0, Math.PI * 2).toFixed(2) });
}

// ---- Points of interest ---------------------------------------------------

// Signal Bunker: central POI
addBuilding(14, -10, 0.3, 'large');
addBuilding(-16, 6, 1.9, 'medium');
addBuilding(2, 22, -0.6, 'small');
addCrateProp(6, 2);
addCrateProp(-4, -8);
scatterRocks(0, 0, 10, 36);

// Harbor Row: eastern POI
addBuilding(108, 58, -2.1, 'medium');
addBuilding(126, 44, 2.4, 'medium');
addBuilding(118, 74, 0.2, 'small');
addCrateProp(114, 60);
addCrateProp(130, 50);
scatterRocks(120, 60, 8, 20);

// Quarry: south-west POI
scatterRocks(-95, -75, 22, 34);
addCrateProp(-92, -70);

// Timberline: dense forest, north-west
scatterTrees(-70, 95, 45, 50);
addCrateProp(-65, 100);

// Outpost 7: south-east POI
addBuilding(78, -102, 1.1, 'small');
addBuilding(92, -90, -0.4, 'small');
addCrateProp(85, -98);
scatterRocks(85, -96, 6, 16);

// General scatter across the rest of the island
scatterTrees(40, -30, 50, 90);
scatterTrees(-20, -110, 30, 50);
scatterTrees(0, 0, 25, 150);
scatterRocks(0, 0, 25, 150);

// ---- Pickups ----------------------------------------------------------

const pickupSpots = [
  [6, 2, 'rifle'], [-4, -8, 'shotgun'], [14, -16, 'health'],
  [114, 60, 'rifle'], [130, 50, 'health'], [122, 70, 'shotgun'],
  [-92, -70, 'shotgun'], [-100, -82, 'health'], [-85, -60, 'rifle'],
  [-65, 100, 'rifle'], [-75, 88, 'health'],
  [85, -98, 'shotgun'], [92, -88, 'rifle'], [78, -108, 'health'],
  [40, 40, 'rifle'], [-40, 40, 'shotgun'], [40, -60, 'health'],
  [-50, -20, 'rifle'], [0, 90, 'shotgun'], [60, 10, 'health']
];
const pickups = pickupSpots.map((spot, i) => ({ id: 'p' + (i + 1), type: spot[2], x: spot[0], z: spot[1] }));

// ---- Zone / spawn config -----------------------------------------------

const mapLayout = {
  mapSize: TERRAIN_HALF * 2,
  terrainHalf: TERRAIN_HALF,
  islandEdge: ISLAND_EDGE,
  dropZoneCenter: { x: 0, y: 85, z: 0 },
  spawnRing: { radius: 132 },
  zone: {
    center: { x: 0, z: 0 },
    initialRadius: 150,
    phases: [
      { shrinkToRadius: 95, waitBeforeSec: 25, shrinkDurationSec: 45, damagePerSec: 2 },
      { shrinkToRadius: 55, waitBeforeSec: 18, shrinkDurationSec: 40, damagePerSec: 4 },
      { shrinkToRadius: 25, waitBeforeSec: 15, shrinkDurationSec: 35, damagePerSec: 6 },
      { shrinkToRadius: 6, waitBeforeSec: 12, shrinkDurationSec: 30, damagePerSec: 10 }
    ]
  },
  props,
  pickups
};

const outPath = path.join(__dirname, '..', 'public', 'shared', 'mapLayout.json');
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(mapLayout, null, 2));
console.log(`Wrote ${props.length} props and ${pickups.length} pickups to ${outPath}`);
