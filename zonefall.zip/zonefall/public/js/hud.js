/**
 * hud.js — everything that touches the in-game DOM overlay: bars, ammo,
 * kill feed, damage flash, countdown, death card and the minimap canvas.
 */
const $ = (id) => document.getElementById(id);

const el = {};
let mapStatic = null;   // pre-rendered island layer
let mapLayout = null;
let lastText = {};

function setText(key, node, value) {
  if (lastText[key] === value) return;
  lastText[key] = value;
  node.textContent = value;
}

export function initHud(layout) {
  mapLayout = layout;
  for (const id of ['hud-layer', 'hud-health-fill', 'hud-health-text', 'hud-stamina-fill', 'hud-alive-count', 'hud-zone-status',
    'hud-minimap-canvas', 'hud-killfeed', 'hud-crosshair', 'hud-weapon-name', 'hud-ammo-text', 'hud-reload-indicator',
    'hud-damage-flash', 'hud-countdown', 'death-overlay', 'death-message']) el[id] = $(id);

  // static minimap layer: sea, island, buildings
  const size = el['hud-minimap-canvas'].width;
  mapStatic = document.createElement('canvas');
  mapStatic.width = mapStatic.height = size;
  const g = mapStatic.getContext('2d');
  const c = size / 2, s = (size / 2 - 4) / layout.terrainHalf;
  g.fillStyle = '#2f6d8d'; g.fillRect(0, 0, size, size);
  g.fillStyle = '#7da35c'; g.beginPath(); g.arc(c, c, layout.islandEdge * s, 0, Math.PI * 2); g.fill();
  g.fillStyle = '#4f7a3f';
  for (const p of layout.props) if (p.type === 'tree') g.fillRect(c + p.x * s - 0.5, c + p.z * s - 0.5, 1.2, 1.2);
  g.fillStyle = '#e8dfc0';
  for (const p of layout.props) if (p.type === 'building') g.fillRect(c + p.x * s - 2, c + p.z * s - 2, 4, 4);
}

export function showHud(on) {
  el['hud-layer'].classList.toggle('hidden', !on);
  if (!on) { el['death-overlay'].classList.add('hidden'); el['hud-countdown'].classList.add('hidden'); }
}

export function resetHud() {
  lastText = {};
  el['hud-killfeed'].innerHTML = '';
  el['death-overlay'].classList.add('hidden');
  el['hud-reload-indicator'].classList.add('hidden');
}

export function setHealth(hp) {
  const v = Math.max(0, Math.ceil(hp));
  el['hud-health-fill'].style.width = v + '%';
  setText('hp', el['hud-health-text'], String(v));
}
export function setStamina(frac) {
  el['hud-stamina-fill'].style.width = Math.round(Math.max(0, Math.min(1, frac)) * 100) + '%';
}
export function setAlive(n) { setText('alive', el['hud-alive-count'], n + ' alive'); }

export function setZoneStatus(text, danger) {
  setText('zone', el['hud-zone-status'], text);
  el['hud-zone-status'].classList.toggle('shrinking', !!danger);
}

export function setWeaponHud(name, mag, reserve, reloading) {
  setText('wname', el['hud-weapon-name'], name);
  setText('ammo', el['hud-ammo-text'], mag + ' / ' + (reserve === Infinity ? '∞' : reserve));
  el['hud-reload-indicator'].classList.toggle('hidden', !reloading);
}

export function killfeedLine(text) {
  const feed = el['hud-killfeed'];
  const line = document.createElement('div');
  line.className = 'kf-line';
  line.textContent = text;
  feed.appendChild(line);
  while (feed.children.length > 4) feed.removeChild(feed.firstChild);
  setTimeout(() => line.remove(), 5500);
}

export function flashDamage() {
  const f = el['hud-damage-flash'];
  f.classList.add('show');
  setTimeout(() => f.classList.remove('show'), 90);
}

let hitTimer = null;
export function hitMarker(head) {
  const spans = el['hud-crosshair'].children;
  for (const s of spans) s.style.background = head ? '#D94F4F' : '#F2832B';
  clearTimeout(hitTimer);
  hitTimer = setTimeout(() => { for (const s of spans) s.style.background = ''; }, 110);
}

export function setCountdown(text) {
  const c = el['hud-countdown'];
  if (text == null) { c.classList.add('hidden'); return; }
  c.classList.remove('hidden');
  c.textContent = text;
}

export function showDeath(msg) {
  el['death-message'].textContent = msg;
  el['death-overlay'].classList.remove('hidden');
}

export function drawMinimap(x, z, yaw, zoneRadius, targetRadius) {
  const cv = el['hud-minimap-canvas'];
  const g = cv.getContext('2d');
  const size = cv.width, c = size / 2, s = (size / 2 - 4) / mapLayout.terrainHalf;
  g.clearRect(0, 0, size, size);
  g.save();
  g.beginPath(); g.arc(c, c, c - 1, 0, Math.PI * 2); g.clip();
  g.drawImage(mapStatic, 0, 0);
  // current safe zone
  g.strokeStyle = '#ECE7DA'; g.lineWidth = 2;
  g.beginPath(); g.arc(c + mapLayout.zone.center.x * s, c + mapLayout.zone.center.z * s, zoneRadius * s, 0, Math.PI * 2); g.stroke();
  // next zone
  if (targetRadius < zoneRadius - 0.5) {
    g.strokeStyle = 'rgba(242,131,43,0.9)'; g.lineWidth = 1.5; g.setLineDash([4, 3]);
    g.beginPath(); g.arc(c + mapLayout.zone.center.x * s, c + mapLayout.zone.center.z * s, targetRadius * s, 0, Math.PI * 2); g.stroke();
    g.setLineDash([]);
  }
  // player arrow (north-up map; forward = (-sin yaw, -cos yaw))
  const px = c + x * s, pz = c + z * s;
  const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
  g.fillStyle = '#F2832B';
  g.beginPath();
  g.moveTo(px + fx * 6, pz + fz * 6);
  g.lineTo(px - fx * 4 + fz * 4, pz - fz * 4 - fx * 4);
  g.lineTo(px - fx * 4 - fz * 4, pz - fz * 4 + fx * 4);
  g.closePath(); g.fill();
  g.restore();
}
