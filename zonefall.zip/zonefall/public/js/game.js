/**
 * game.js — the match itself: local player physics + camera, shooting,
 * remote players, pickups, zone, HUD updates and the 10 Hz network send.
 *
 * Yaw convention (same as three.js cameras): the player faces
 *   forward = (-sin yaw, -cos yaw)  on the (x, z) plane,
 * and the avatar group's rotation.y equals yaw, so what you see is where
 * the character points.
 */
import * as THREE from 'three';
import {
  world, initWorld, terrainHeight, resolveCollisions, rayObstruction,
  clearPickups, addPickup, removePickup, animatePickups, setZoneRadius, resizeWorld
} from './world.js';
import { Avatar, RemotePlayer, spawnTracer, updateTracers } from './players.js';
import { input, initControls, setControlsEnabled, clearSprint, exitPointerLock } from './controls.js';
import { WEAPONS, newInventory, grantWeapon } from './weapons.js';
import * as hud from './hud.js';
import * as sfx from './audio.js';

const WALK = 5.2, SPRINT = 8.2, JUMP_V = 7.2, GRAVITY = 22;
const PLAYER_RADIUS = 0.38, WORLD_LIMIT = 160;
const CAM_DIST = 3.3, CAM_SHOULDER = 0.65, EYE = 1.55;
const NET_INTERVAL = 0.1;

const G = {
  ready: false,
  active: false,
  phase: 'idle',          // idle | countdown | playing | dead | over
  socket: null,
  myId: null,
  me: null,
  remotes: new Map(),
  aliveCount: 0,
  zone: { radius: 150, target: 150, visual: 150, shrinkStartAt: null, shrinkEndAt: null },
  clockOffset: 0,         // serverTime - clientTime
  countdownEnd: 0,
  lastCountText: null,
  netTimer: 0,
  mapTimer: 0,
  lastFrame: 0,
  pickupAsked: new Map(),
  spectateId: null,
  names: new Map()
};

const raycaster = new THREE.Raycaster();
const _v1 = new THREE.Vector3(), _v2 = new THREE.Vector3(), _dir = new THREE.Vector3(), _org = new THREE.Vector3();

// ================================ setup ====================================

export function initGame(container, layout) {
  initWorld(container, layout);
  initControls(container);
  hud.initHud(layout);
  raycaster.camera = world.camera;
  G.ready = true;
}

function makeMe(spawn, index, username) {
  const avatar = new Avatar(index, username, false);
  const yaw = Math.atan2(spawn.x, spawn.z);          // face the island centre
  return {
    avatar, username,
    x: spawn.x, y: spawn.y, z: spawn.z,
    vy: 0, speed: 0,
    yaw, pitch: -0.35,
    onGround: false, mode: 'drop', parachute: false,
    hp: 100, stamina: 100, exhausted: false,
    alive: true,
    inv: newInventory(), weapon: 'pistol',
    lastShotAt: 0, fireBufferAt: -1, reloadEnd: 0, reloading: false,
    jumpBuffer: 0, kills: 0
  };
}

/**
 * Called on 'matchStarting'. spawns: [{id,x,y,z}], pickups: [{id,type,x,z}],
 * names: Map(socketId -> username).
 */
export function startRound({ socket, myId, spawns, pickups, names, countdownSec }) {
  resizeWorld();
  stopRound(true);
  G.socket = socket; G.myId = myId; G.names = names;
  G.phase = 'countdown';
  G.aliveCount = spawns.length;
  G.zone = { radius: world.layout.zone.initialRadius, target: world.layout.zone.initialRadius, visual: world.layout.zone.initialRadius, shrinkStartAt: null, shrinkEndAt: null };
  setZoneRadius(G.zone.visual);
  G.pickupAsked.clear();
  G.netTimer = 0; G.mapTimer = 0;

  spawns.forEach((s, i) => {
    const name = names.get(s.id) || 'Player';
    if (s.id === myId) G.me = makeMe(s, i, name);
    else {
      const rp = new RemotePlayer(s.id, i, name);
      rp.snapTo(s.x, s.y, s.z, Math.atan2(s.x, s.z));
      G.remotes.set(s.id, rp);
    }
  });
  clearPickups();
  for (const p of pickups) addPickup(p.id, p.type, p.x, p.z);

  hud.resetHud();
  hud.showHud(true);
  hud.setHealth(100); hud.setStamina(1); hud.setAlive(G.aliveCount); hud.setZoneStatus('Safe', false);
  refreshWeaponHud();
  setControlsEnabled(true);

  G.countdownEnd = performance.now() + countdownSec * 1000;
  G.lastCountText = null;
  G.active = true;
  G.lastFrame = performance.now();
  world.renderer.setAnimationLoop(frame);
}

export function beginPlay(startedAt) {
  if (!G.active) return;
  G.clockOffset = startedAt - Date.now();
  G.phase = 'playing';
  G.me.mode = 'drop';
  hud.setCountdown('DROP!');
  sfx.playCount(true);
  setTimeout(() => { if (G.phase === 'playing' || G.phase === 'dead') hud.setCountdown(null); }, 1100);
}

export function stopRound(keepRenderer) {
  if (!G.ready) return;
  G.active = false;
  G.phase = 'idle';
  if (world.renderer && !keepRenderer) world.renderer.setAnimationLoop(null);
  for (const r of G.remotes.values()) r.dispose();
  G.remotes.clear();
  if (G.me) { G.me.avatar.dispose(); G.me = null; }
  clearPickups();
  setControlsEnabled(false);
  clearSprint();
  exitPointerLock();
  hud.showHud(false);
}

export function endRound() {
  G.phase = 'over';
  setControlsEnabled(false);
  exitPointerLock();
}

// ============================ server events ================================

export const netHandlers = {
  playerMoved(d) {
    const r = G.remotes.get(d.id);
    if (r && r.alive) r.applySnapshot(d);
  },
  shotFired(d) {
    if (!G.active) return;
    const r = G.remotes.get(d.id);
    if (!r || !G.me) return;
    r.avatar.muzzleFlash();
    const dist = Math.hypot(r.avatar.group.position.x - G.me.x, r.avatar.group.position.z - G.me.z);
    sfx.playShot(d.weapon, Math.max(0, 1 - dist / 140));
  },
  healthUpdate(d) {
    if (!G.active) return;
    if (!G.me || d.id !== G.myId) return;
    if (d.hp < G.me.hp) { hud.flashDamage(); sfx.playHurt(); }
    else if (d.hp > G.me.hp) sfx.playPickup();
    G.me.hp = d.hp;
    hud.setHealth(d.hp);
  },
  playerEliminated(d) {
    if (!G.active) return;
    G.aliveCount = Math.max(0, G.aliveCount - 1);
    hud.setAlive(G.aliveCount);
    const victim = d.username || 'Someone';
    hud.killfeedLine(d.by ? `${d.by} eliminated ${victim}` : `${victim} was lost to the zone`);
    if (G.me && d.id === G.myId) {
      G.me.alive = false; G.phase = 'dead';
      G.me.avatar.setDead();
      input.fireHeld = false;
      hud.showDeath(`#${d.placement} — ${d.by ? 'Eliminated by ' + d.by : 'Claimed by the zone'}`);
    } else {
      const r = G.remotes.get(d.id);
      if (r) r.die();
    }
  },
  pickupRemoved(d) { removePickup(d.id); },
  weaponGranted(d) {
    if (!G.me) return;
    grantWeapon(G.me.inv, d.weapon);
    sfx.playPickup();
    switchTo(d.weapon);
  },
  zoneUpdate(d) {
    if (!G.active) return;
    G.zone.radius = d.radius;
    G.zone.target = d.targetRadius;
    G.zone.shrinkStartAt = d.shrinkStartAt;
    G.zone.shrinkEndAt = d.shrinkEndAt;
  }
};

// ============================== weapons ====================================

function refreshWeaponHud() {
  const me = G.me; if (!me) return;
  const w = WEAPONS[me.weapon], slot = me.inv[me.weapon];
  hud.setWeaponHud(w.name, slot.mag, slot.reserve, me.reloading);
}

function switchTo(id) {
  const me = G.me;
  if (!me || !me.inv[id]) return;
  me.weapon = id;
  me.reloading = false;
  me.avatar.setWeapon(id);
  refreshWeaponHud();
}

function cycleWeapon() {
  const me = G.me;
  const owned = ['pistol', 'rifle', 'shotgun'].filter((id) => me.inv[id]);
  if (owned.length < 2) return;
  switchTo(owned[(owned.indexOf(me.weapon) + 1) % owned.length]);
  sfx.playReload();
}

function startReload(now) {
  const me = G.me;
  const w = WEAPONS[me.weapon], slot = me.inv[me.weapon];
  if (me.reloading || slot.mag >= w.magSize || slot.reserve <= 0) return;
  me.reloading = true;
  me.reloadEnd = now + w.reloadSec * 1000;
  sfx.playReload();
  refreshWeaponHud();
}

function finishReload() {
  const me = G.me;
  const w = WEAPONS[me.weapon], slot = me.inv[me.weapon];
  const take = Math.min(w.magSize - slot.mag, slot.reserve);
  slot.mag += take;
  slot.reserve -= take;
  me.reloading = false;
  refreshWeaponHud();
}

function fireWeapon(now) {
  const me = G.me, w = WEAPONS[me.weapon], slot = me.inv[me.weapon];
  me.lastShotAt = now;
  slot.mag--;

  const cam = world.camera;
  const hits = new Map(); // targetId -> { hits, head }
  const candidates = [];
  for (const r of G.remotes.values()) if (r.alive) candidates.push(r.avatar.group);
  for (const g of candidates) g.updateMatrixWorld(true);

  me.avatar.muzzleWorldPosition(_v1);
  const muzzle = _v1.clone();
  let lastEnd = _v2;

  for (let i = 0; i < w.pellets; i++) {
    // random cone around the crosshair direction
    const yaw = me.yaw + (Math.random() - 0.5) * 2 * w.spread;
    const pitch = me.pitch + (Math.random() - 0.5) * 2 * w.spread;
    _dir.set(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));
    _org.copy(cam.position);

    let dist = w.range;
    const wall = rayObstruction(_org.x, _org.y, _org.z, _dir.x, _dir.y, _dir.z, w.range);
    if (wall < dist) dist = wall;

    let targetId = null, head = false;
    if (candidates.length) {
      raycaster.set(_org, _dir);
      raycaster.far = dist;
      const found = raycaster.intersectObjects(candidates, true);
      for (const h of found) {
        if (!h.object.userData.hitPart) continue;
        // walk up to the avatar group to know which player it was
        let o = h.object;
        while (o && !candidates.includes(o)) o = o.parent;
        if (!o) continue;
        for (const [id, r] of G.remotes) if (r.avatar.group === o) targetId = id;
        head = h.object.userData.hitPart === 'head';
        dist = h.distance;
        break;
      }
    }
    if (targetId) {
      const rec = hits.get(targetId) || { hits: 0, head: false };
      rec.hits++; rec.head = rec.head || head;
      hits.set(targetId, rec);
    }
    lastEnd = _org.clone().addScaledVector(_dir, dist);
    if (i < 3) spawnTracer(muzzle, lastEnd); // cap tracer count for shotgun blasts
  }

  me.avatar.muzzleFlash();
  sfx.playShot(me.weapon, 1);
  G.socket.emit('shotFired');
  for (const [targetId, rec] of hits) {
    const part = w.pellets === 1 && rec.head ? 'head' : 'body';
    G.socket.emit('playerHit', { targetId, weaponId: me.weapon, part, hits: rec.hits });
    hud.hitMarker(part === 'head');
    sfx.playHit(part === 'head');
  }

  // recoil kick
  me.pitch = Math.min(me.pitch + w.recoil, 1.0);
  me.yaw += (Math.random() - 0.5) * w.recoil * 0.6;
  refreshWeaponHud();
}

// ============================ local simulation =============================

function updateLocal(dt, now) {
  const me = G.me;

  // look (allowed in every phase, including the countdown)
  me.yaw -= input.lookDX;
  me.pitch = Math.max(-1.0, Math.min(1.0, me.pitch - input.lookDY));
  input.lookDX = input.lookDY = 0;

  if (G.phase !== 'playing' || !me.alive) { me.avatar.animate(dt, 0, 'drop'); return; }

  // wish direction
  let mx = input.moveX, my = input.moveY;
  const len = Math.hypot(mx, my);
  if (len > 1) { mx /= len; my /= len; }
  const fx = -Math.sin(me.yaw), fz = -Math.cos(me.yaw);
  const rx = Math.cos(me.yaw), rz = -Math.sin(me.yaw);
  const wishX = fx * my + rx * mx, wishZ = fz * my + rz * mx;
  const moving = len > 0.05;

  const ground = terrainHeight(me.x, me.z);
  let speed;

  if (me.mode === 'drop') {
    const alt = me.y - ground;
    const diving = input.sprint && alt > 32;
    me.parachute = !diving;
    me.vy = diving ? -26 : -9;
    speed = diving ? 20 : 15;
    me.x += wishX * speed * dt; me.z += wishZ * speed * dt;
    me.y += me.vy * dt;
    const g2 = terrainHeight(me.x, me.z);
    if (me.y <= g2 + 0.02) { // touchdown
      me.y = g2; me.vy = 0; me.mode = 'ground'; me.parachute = false; me.onGround = true;
      clearSprint();
    }
    me.speed = 0;
  } else {
    const wantSprint = input.sprint && moving && !me.exhausted && me.stamina > 0;
    speed = wantSprint ? SPRINT : WALK;
    if (wantSprint) {
      me.stamina = Math.max(0, me.stamina - 22 * dt);
      if (me.stamina <= 0) { me.exhausted = true; clearSprint(); }
    } else {
      me.stamina = Math.min(100, me.stamina + 14 * dt);
      if (me.exhausted && me.stamina > 25) me.exhausted = false;
    }
    if (me.reloading) speed *= 0.85;

    me.x += wishX * speed * dt; me.z += wishZ * speed * dt;
    const fixed = resolveCollisions(me.x, me.z, PLAYER_RADIUS, me.y);
    me.x = fixed.x; me.z = fixed.z;
    const r = Math.hypot(me.x, me.z);
    if (r > WORLD_LIMIT) { me.x *= WORLD_LIMIT / r; me.z *= WORLD_LIMIT / r; }

    if (input.jumpPressed) me.jumpBuffer = now;
    if (me.onGround && now - me.jumpBuffer < 150) { me.vy = JUMP_V; me.onGround = false; me.jumpBuffer = 0; }
    me.vy -= GRAVITY * dt;
    me.y += me.vy * dt;
    const g2 = terrainHeight(me.x, me.z);
    if (me.y <= g2) { me.y = g2; me.vy = 0; me.onGround = true; }
    else if (me.onGround && me.y - g2 < 0.35 && me.vy <= 0) { me.y = g2; me.vy = 0; } // stay glued going downhill
    else if (me.y - g2 > 0.05) me.onGround = false;

    me.speed = moving ? speed * Math.min(len, 1) : 0;
  }
  input.jumpPressed = false;
  hud.setStamina(me.stamina / 100);
}

function updateLocalAvatar(dt) {
  const me = G.me, a = me.avatar;
  a.group.position.set(me.x, me.y, me.z);
  a.group.rotation.y = me.yaw;
  a.setParachute(me.mode === 'drop' && me.parachute && G.phase === 'playing');
  if (me.alive) a.animate(dt, me.speed, me.mode === 'drop' ? 'drop' : 'ground');
}

// ================================ camera ===================================

function updateCamera(dt) {
  const me = G.me, cam = world.camera;
  let px = me.x, py = me.y, pz = me.z;
  let yaw = me.yaw, pitch = me.pitch;

  if (!me.alive) { // spectate someone still alive
    let t = G.remotes.get(G.spectateId);
    if (!t || !t.alive) {
      t = null;
      for (const r of G.remotes.values()) if (r.alive) { t = r; G.spectateId = r.id; break; }
    }
    if (t) { const p = t.avatar.group.position; px = p.x; py = p.y; pz = p.z; }
  }

  const cp = Math.cos(pitch);
  _dir.set(-Math.sin(yaw) * cp, Math.sin(pitch), -Math.cos(yaw) * cp);
  const rx = Math.cos(yaw), rz = -Math.sin(yaw);
  const dist = me.mode === 'drop' && G.phase !== 'countdown' ? 4.6 : CAM_DIST;
  cam.position.set(
    px - _dir.x * dist + rx * CAM_SHOULDER,
    py + EYE - _dir.y * dist,
    pz - _dir.z * dist + rz * CAM_SHOULDER
  );
  const floor = terrainHeight(cam.position.x, cam.position.z) + 0.45;
  if (cam.position.y < floor) cam.position.y = floor;
  cam.rotation.set(pitch, yaw, 0);
  if (world.sky) world.sky.position.copy(cam.position);
}

// ============================== pickups ====================================

function checkPickups(now) {
  const me = G.me;
  if (me.mode !== 'ground') return;
  for (const [id, p] of world.pickups) {
    if (Math.hypot(me.x - p.x, me.z - p.z) > 2.2) continue;
    if (p.type === 'health' && me.hp >= 100) continue;
    if (now - (G.pickupAsked.get(id) || 0) < 700) continue;
    G.pickupAsked.set(id, now);
    G.socket.emit('pickupCollected', { id });
  }
}

// ================================ HUD ======================================

function updateZoneHud() {
  const me = G.me, z = G.zone;
  const d = Math.hypot(me.x - world.layout.zone.center.x, me.z - world.layout.zone.center.z);
  if (me.alive && d > z.visual + 0.5 && G.phase === 'playing') { hud.setZoneStatus('OUTSIDE ZONE', true); return; }
  if (z.shrinkStartAt == null) { hud.setZoneStatus('Safe', false); return; }
  const nowS = Date.now() + G.clockOffset;
  if (nowS < z.shrinkStartAt) hud.setZoneStatus('Zone closes in ' + Math.ceil((z.shrinkStartAt - nowS) / 1000) + 's', false);
  else if (nowS < z.shrinkEndAt) hud.setZoneStatus('Zone shrinking', true);
  else hud.setZoneStatus('Zone holding', false);
}

function updateCountdown(now) {
  if (G.phase !== 'countdown') return;
  const left = Math.max(0, Math.ceil((G.countdownEnd - now) / 1000));
  const text = left > 0 ? String(left) : '';
  if (text !== G.lastCountText) {
    G.lastCountText = text;
    hud.setCountdown(text || null);
    if (text) sfx.playCount(false);
  }
}

// ================================ frame ====================================

function frame(nowMs) {
  if (!G.active || !G.me) return;
  const dt = Math.min((nowMs - G.lastFrame) / 1000, 0.05);
  G.lastFrame = nowMs;
  const me = G.me;

  updateCountdown(nowMs);
  updateLocal(dt, nowMs);
  updateLocalAvatar(dt);
  updateCamera(dt);

  // shooting (after the camera is placed so the ray matches what you see)
  if (G.phase === 'playing' && me.alive && me.mode === 'ground') {
    if (input.switchPressed) cycleWeapon();
    if (input.reloadPressed) startReload(nowMs);
    if (me.reloading && nowMs >= me.reloadEnd) finishReload();

    if (input.firePressed) me.fireBufferAt = nowMs;
    const w = WEAPONS[me.weapon], slot = me.inv[me.weapon];
    const wantsFire = (nowMs - me.fireBufferAt < 160) || (input.fireHeld && w.auto);
    if (wantsFire && !me.reloading && nowMs - me.lastShotAt >= w.intervalMs) {
      if (slot.mag > 0) { fireWeapon(nowMs); me.fireBufferAt = -1; }
      else if (slot.reserve > 0) startReload(nowMs);
      else if (input.firePressed) { sfx.playEmpty(); me.fireBufferAt = -1; }
    }
    checkPickups(nowMs);
  }
  input.firePressed = input.jumpPressed = input.reloadPressed = input.switchPressed = false;

  for (const r of G.remotes.values()) r.update(dt);
  animatePickups(nowMs / 1000);
  updateTracers(dt);

  // zone wall eases toward the server's radius
  G.zone.visual += (G.zone.radius - G.zone.visual) * Math.min(1, dt * 3);
  setZoneRadius(G.zone.visual);

  // network
  G.netTimer += dt;
  if (G.netTimer >= NET_INTERVAL && G.phase === 'playing' && me.alive) {
    G.netTimer = 0;
    G.socket.volatile.emit('playerUpdate', {
      x: round2(me.x), y: round2(me.y), z: round2(me.z), ry: round2(me.yaw), weapon: me.weapon,
      anim: me.mode === 'drop' ? 'drop' : (me.speed > 0.5 ? 'run' : 'idle')
    });
  }

  // slow HUD work
  G.mapTimer += dt;
  if (G.mapTimer > 0.15) {
    G.mapTimer = 0;
    hud.drawMinimap(me.x, me.z, me.yaw, G.zone.visual, G.zone.target);
    updateZoneHud();
  }

  world.renderer.render(world.scene, world.camera);
}

function round2(n) { return Math.round(n * 100) / 100; }
