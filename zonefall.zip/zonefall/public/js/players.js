/**
 * players.js — builds and animates player avatars (local + remote), name
 * tags, parachutes, muzzle flashes and bullet tracers.
 */
import * as THREE from 'three';
import { buildCharacter, buildWeaponMesh, buildParachuteGroup, colorForIndex } from './objectBuilders.js';
import { world, terrainHeight } from './world.js';

const FLASH_GEO = new THREE.OctahedronGeometry(0.1, 0);
const FLASH_MAT = new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.95, fog: false });
const TRACER_GEO = new THREE.BoxGeometry(0.025, 0.025, 1);
const TRACER_MAT = new THREE.MeshBasicMaterial({ color: 0xffe0a0, transparent: true, opacity: 0.8, fog: false });

function makeNameTag(name) {
  const cv = document.createElement('canvas');
  cv.width = 256; cv.height = 64;
  const g = cv.getContext('2d');
  g.font = '700 34px "Big Shoulders Display", Arial, sans-serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.lineWidth = 6; g.strokeStyle = 'rgba(22,28,23,0.9)';
  g.strokeText(name, 128, 34);
  g.fillStyle = '#ECE7DA';
  g.fillText(name, 128, 34);
  const tex = new THREE.CanvasTexture(cv);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
  sprite.scale.set(1.9, 0.48, 1);
  sprite.position.y = 2.15;
  sprite.raycast = () => {}; // name tags must never absorb bullets
  return sprite;
}

/** One avatar: character + held weapon + (optional) parachute + muzzle flash. */
export class Avatar {
  constructor(index, username, withTag) {
    this.index = index;
    this.username = username;
    this.color = colorForIndex(index);
    const built = buildCharacter(this.color);
    this.group = built.group;
    this.parts = built.parts;
    this.weaponId = null;
    this.weaponMesh = null;
    this.parachute = null;
    this.walkPhase = 0;
    this.flashTimer = 0;
    this.flash = new THREE.Mesh(FLASH_GEO, FLASH_MAT);
    this.flash.visible = false;
    if (withTag) this.group.add(makeNameTag(username));
    this.alive = true;
    this.setWeapon('pistol');
    world.scene.add(this.group);
  }

  setWeapon(id) {
    if (this.weaponId === id) return;
    this.weaponId = id;
    if (this.weaponMesh) this.parts.weaponMount.remove(this.weaponMesh);
    this.weaponMesh = buildWeaponMesh(id);
    this.parts.weaponMount.add(this.weaponMesh);
    this.flash.position.copy(this.weaponMesh.userData.muzzleOffset);
    this.weaponMesh.add(this.flash);
    this.parts.rightShoulder.rotation.x = 1.25; // aiming arm raised toward the target
  }

  setParachute(on) {
    if (on && !this.parachute) { this.parachute = buildParachuteGroup(this.color); this.group.add(this.parachute); }
    else if (!on && this.parachute) { this.group.remove(this.parachute); this.parachute = null; }
  }

  /** Procedural walk cycle. speed is m/s on the ground; mode 'drop' holds a skydiver pose. */
  animate(dt, speed, mode) {
    const p = this.parts;
    if (mode === 'drop') {
      p.leftHip.rotation.x = 0.25; p.rightHip.rotation.x = -0.15;
      p.leftShoulder.rotation.x = -2.6;
    } else {
      this.walkPhase += dt * (4 + speed * 1.1);
      const amp = Math.min(speed / 6, 1.2) * 0.75;
      const s = Math.sin(this.walkPhase) * amp;
      p.leftHip.rotation.x = s;
      p.rightHip.rotation.x = -s;
      p.leftShoulder.rotation.x = -s * 0.9;
    }
    // keep the shadow blob on the floor (ground height under the avatar)
    p.shadowBlob.position.y = terrainHeight(this.group.position.x, this.group.position.z) - this.group.position.y + 0.04;
    if (this.flashTimer > 0) {
      this.flashTimer -= dt;
      this.flash.visible = this.flashTimer > 0;
    }
  }

  muzzleFlash() { this.flashTimer = 0.05; this.flash.visible = true; }

  muzzleWorldPosition(out) {
    this.group.updateMatrixWorld(true);
    return this.weaponMesh.localToWorld(out.copy(this.weaponMesh.userData.muzzleOffset));
  }

  setDead() {
    this.alive = false;
    this.setParachute(false);
    this.group.rotation.z = Math.PI / 2;
    this.group.position.y += 0.25;
    this.flash.visible = false;
  }

  dispose() {
    world.scene.remove(this.group);
  }
}

/** A remote player: an Avatar plus smoothing toward the last network snapshot. */
export class RemotePlayer {
  constructor(id, index, username) {
    this.id = id;
    this.avatar = new Avatar(index, username, true);
    this.target = { x: 0, y: 0, z: 0, ry: 0 };
    this.speed = 0;
    this.anim = 'idle';
    this.snapped = false;
    this.lastX = 0; this.lastZ = 0;
  }
  get alive() { return this.avatar.alive; }

  applySnapshot(s) {
    this.target.x = s.x; this.target.y = s.y; this.target.z = s.z; this.target.ry = s.ry;
    this.anim = s.anim || 'idle';
    if (s.weapon) this.avatar.setWeapon(s.weapon);
    if (!this.snapped) { this.snapTo(s.x, s.y, s.z, s.ry); }
  }

  snapTo(x, y, z, ry) {
    const g = this.avatar.group;
    g.position.set(x, y, z); g.rotation.y = ry;
    this.target.x = x; this.target.y = y; this.target.z = z; this.target.ry = ry;
    this.lastX = x; this.lastZ = z;
    this.snapped = true;
  }

  update(dt) {
    const a = this.avatar;
    if (!a.alive) { a.animate(dt, 0, 'ground'); return; }
    const g = a.group;
    const k = 1 - Math.exp(-14 * dt);
    g.position.x += (this.target.x - g.position.x) * k;
    g.position.y += (this.target.y - g.position.y) * k;
    g.position.z += (this.target.z - g.position.z) * k;
    let dy = this.target.ry - g.rotation.y;
    dy = Math.atan2(Math.sin(dy), Math.cos(dy));
    g.rotation.y += dy * k;
    const mvx = g.position.x - this.lastX, mvz = g.position.z - this.lastZ;
    this.speed += (Math.hypot(mvx, mvz) / Math.max(dt, 0.001) - this.speed) * Math.min(1, dt * 8);
    this.lastX = g.position.x; this.lastZ = g.position.z;
    const dropping = this.anim === 'drop';
    a.setParachute(dropping);
    a.animate(dt, dropping ? 0 : this.speed, dropping ? 'drop' : 'ground');
  }

  die() { this.avatar.setDead(); }
  dispose() { this.avatar.dispose(); }
}

// ================================ tracers ===================================

const tracers = [];
const _a = new THREE.Vector3(), _b = new THREE.Vector3();

export function spawnTracer(from, to) {
  let t = tracers.find((x) => !x.mesh.visible);
  if (!t) {
    if (tracers.length >= 14) return;
    const mesh = new THREE.Mesh(TRACER_GEO, TRACER_MAT);
    world.scene.add(mesh);
    t = { mesh, life: 0 };
    tracers.push(t);
  }
  _a.copy(from); _b.copy(to);
  const len = _a.distanceTo(_b);
  t.mesh.position.copy(_a).lerp(_b, 0.5);
  t.mesh.scale.set(1, 1, Math.max(len, 0.01));
  t.mesh.lookAt(_b);
  t.mesh.visible = true;
  t.life = 0.07;
}

export function updateTracers(dt) {
  for (const t of tracers) {
    if (!t.mesh.visible) continue;
    t.life -= dt;
    if (t.life <= 0) t.mesh.visible = false;
  }
}
