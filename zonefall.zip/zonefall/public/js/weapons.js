/**
 * weapons.js — client-side weapon table. Damage numbers here are only used
 * for the HUD; the server owns the real damage values (see WEAPON_STATS in
 * server.js) and ignores whatever the client claims.
 */
export const WEAPONS = {
  pistol:  { name: 'Pistol',  magSize: 12, startReserve: Infinity, reloadSec: 1.1, intervalMs: 330, auto: false, pellets: 1, spread: 0.010, range: 70,  recoil: 0.018 },
  rifle:   { name: 'Rifle',   magSize: 30, startReserve: 60,       reloadSec: 1.8, intervalMs: 130, auto: true,  pellets: 1, spread: 0.018, range: 130, recoil: 0.014 },
  shotgun: { name: 'Shotgun', magSize: 6,  startReserve: 18,       reloadSec: 2.3, intervalMs: 850, auto: false, pellets: 6, spread: 0.060, range: 32,  recoil: 0.060 }
};

/** A fresh loadout: everyone starts with the infinite-ammo pistol. */
export function newInventory() {
  return { pistol: { mag: WEAPONS.pistol.magSize, reserve: Infinity } };
}

/** Add (or top up) a weapon picked up from the ground. */
export function grantWeapon(inv, id) {
  const w = WEAPONS[id];
  if (!w) return;
  if (inv[id]) inv[id].reserve += w.startReserve;
  else inv[id] = { mag: w.magSize, reserve: w.startReserve };
}
