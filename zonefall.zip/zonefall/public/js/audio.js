/**
 * audio.js — all sound is synthesised on the fly with WebAudio (noise
 * bursts and short oscillator blips). No audio files, nothing to download.
 */
let ctx = null;
let master = null;
let noiseBuf = null;

export function unlockAudio() {
  if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  ctx = new AC();
  master = ctx.createGain();
  master.gain.value = 0.5;
  master.connect(ctx.destination);
  noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.4, ctx.sampleRate);
  const d = noiseBuf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
}

function noise(dur, freq, vol, type) {
  if (!ctx) return;
  const src = ctx.createBufferSource(); src.buffer = noiseBuf;
  const f = ctx.createBiquadFilter(); f.type = type || 'lowpass'; f.frequency.value = freq;
  const g = ctx.createGain();
  g.gain.setValueAtTime(vol, ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
  src.connect(f); f.connect(g); g.connect(master);
  src.start(); src.stop(ctx.currentTime + dur);
}
function blip(freq, dur, vol, type) {
  if (!ctx) return;
  const o = ctx.createOscillator(); o.type = type || 'square'; o.frequency.value = freq;
  const g = ctx.createGain();
  g.gain.setValueAtTime(vol, ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
  o.connect(g); g.connect(master);
  o.start(); o.stop(ctx.currentTime + dur);
}

/** volume 0..1 (use < 1 for far-away shots) */
export function playShot(weaponId, volume) {
  const v = volume == null ? 1 : volume;
  if (v <= 0.02) return;
  if (weaponId === 'shotgun') noise(0.26, 900, 0.9 * v);
  else if (weaponId === 'rifle') noise(0.12, 2600, 0.6 * v);
  else noise(0.09, 3200, 0.5 * v);
}
export function playHit(head) { blip(head ? 1300 : 800, 0.07, 0.18, 'triangle'); }
export function playHurt() { blip(150, 0.14, 0.25, 'sawtooth'); }
export function playPickup() { blip(660, 0.08, 0.15, 'triangle'); setTimeout(() => blip(990, 0.1, 0.15, 'triangle'), 70); }
export function playReload() { blip(300, 0.05, 0.12); setTimeout(() => blip(420, 0.06, 0.12), 140); }
export function playEmpty() { blip(180, 0.04, 0.1); }
export function playCount(final) { blip(final ? 880 : 520, final ? 0.3 : 0.12, 0.18, 'triangle'); }
