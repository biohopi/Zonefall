/**
 * world.js — renderer, scene, terrain, instanced props, pickups, safe-zone
 * wall, and the circle colliders used for movement + shot blocking.
 * Everything is procedural; positions come from shared/mapLayout.json so the
 * client and server agree on where the zone, pickups and props are.
 */
import * as THREE from 'three';
import {
  MAT, FOLIAGE_MAT, ROCK_INSTANCE_MAT, geometries,
  buildBuildingGroup, buildCrateGroup, buildPickupMarker,
  TREE_COLLISION_RADIUS, ROCK_COLLISION_RADIUS
} from './objectBuilders.js';

export const world = {
  layout: null,
  scene: null,
  camera: null,
  renderer: null,
  colliders: [],          // { x, z, r, y0, h }
  pickups: new Map(),     // id -> { group, type, baseY }
  zoneWall: null,
  zoneRadius: 150,
  flats: []               // flattened terrain discs around buildings
};

const smooth = (a, b, x) => { const t = Math.min(Math.max((x - a) / (b - a), 0), 1); return t * t * (3 - 2 * t); };

/** Ground height at (x, z). Shared by visuals, player movement and prop placement. */
export function terrainHeight(x, z) {
  const L = world.layout;
  let h = Math.sin(x * 0.045) * 1.5 + Math.cos(z * 0.038) * 1.3 + Math.sin((x + z) * 0.09) * 0.6 + 1.4;
  // calm the ground around buildings so they never float or sink
  let flat = 1;
  for (let i = 0; i < world.flats.length; i++) {
    const f = world.flats[i];
    flat = Math.min(flat, smooth(f.r0, f.r1, Math.hypot(x - f.x, z - f.z)));
  }
  h = 0.9 + (h - 0.9) * flat;
  // island falloff into the sea
  const d = Math.hypot(x, z);
  if (d > L.islandEdge) h -= (d - L.islandEdge) * 0.38;
  return h;
}

export function initWorld(container, layout) {
  world.layout = layout;
  world.flats = layout.props.filter((p) => p.type === 'building').map((p) => ({ x: p.x, z: p.z, r0: 7, r1: 16 }));

  // ------------------------------- renderer ------------------------------
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight, false);
  container.appendChild(renderer.domElement);
  world.renderer = renderer;

  const scene = new THREE.Scene();
  const FOG = 0xbfd9e4;
  scene.background = new THREE.Color(FOG);
  scene.fog = new THREE.Fog(FOG, 70, 250);
  world.scene = scene;

  const camera = new THREE.PerspectiveCamera(68, window.innerWidth / window.innerHeight, 0.1, 420);
  camera.rotation.order = 'YXZ';
  world.camera = camera;

  // -------------------------------- light --------------------------------
  scene.add(new THREE.HemisphereLight(0xe6f1ff, 0x6f7d54, 1.0));
  const sun = new THREE.DirectionalLight(0xfff0d2, 1.15);
  sun.position.set(80, 140, 50);
  scene.add(sun);

  buildSky(scene);
  buildTerrain(scene, layout);
  buildWater(scene);
  buildProps(scene, layout);
  buildZoneWall(scene, layout);

  window.addEventListener('resize', resizeWorld);
  window.addEventListener('orientationchange', () => setTimeout(resizeWorld, 250));
  return world;
}

export function resizeWorld() {
  if (!world.renderer) return;
  const c = world.renderer.domElement.parentElement;
  const w = (c && c.clientWidth) || window.innerWidth;
  const h = (c && c.clientHeight) || window.innerHeight;
  world.renderer.setSize(w, h, false);
  world.camera.aspect = w / h;
  world.camera.updateProjectionMatrix();
}

// ================================== sky ===================================

function buildSky(scene) {
  const geo = new THREE.SphereGeometry(380, 16, 10);
  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const top = new THREE.Color(0x4f8fc7), mid = new THREE.Color(0xbfd9e4), c = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const t = Math.min(Math.max(pos.getY(i) / 380, 0), 1);
    c.copy(mid).lerp(top, Math.pow(t, 0.6));
    colors.set([c.r, c.g, c.b], i * 3);
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const sky = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false }));
  sky.renderOrder = -1;
  scene.add(sky);
  world.sky = sky;
}

// ================================ terrain =================================

function buildTerrain(scene, layout) {
  const half = layout.terrainHalf;
  const segs = 85;
  const geo = new THREE.PlaneGeometry(half * 2, half * 2, segs, segs);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const sand = new THREE.Color(0xd8c58f), grassA = new THREE.Color(0x6c9a4c), grassB = new THREE.Color(0x4f8040), hill = new THREE.Color(0x8a9a5a), c = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    const h = terrainHeight(x, z);
    pos.setY(i, h);
    const n = (Math.sin(x * 0.21) + Math.cos(z * 0.17) + Math.sin((x - z) * 0.11)) / 3; // -1..1
    if (h < 0.35) c.copy(sand);
    else {
      c.copy(grassA).lerp(grassB, 0.5 + 0.5 * n);
      if (h > 2.1) c.lerp(hill, Math.min((h - 2.1) / 1.2, 1) * 0.7);
      if (h < 0.75) c.lerp(sand, (0.75 - h) / 0.4);
    }
    colors.set([c.r, c.g, c.b], i * 3);
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  scene.add(new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true })));
}

function buildWater(scene) {
  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(1400, 1400),
    new THREE.MeshLambertMaterial({ color: 0x3f87b0, transparent: true, opacity: 0.92 })
  );
  water.rotation.x = -Math.PI / 2;
  water.position.y = -0.55;
  scene.add(water);
}

// ================================= props ==================================

function addCollider(x, z, r, y0, h) { world.colliders.push({ x, z, r, y0, h }); }

function buildProps(scene, layout) {
  const trees = layout.props.filter((p) => p.type === 'tree');
  const rocks = layout.props.filter((p) => p.type === 'rock');
  const geo = geometries();
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0), col = new THREE.Color();

  // trees: one instanced mesh for trunks, one for foliage (per-instance green)
  const trunks = new THREE.InstancedMesh(geo.treeTrunk, MAT.bark, Math.max(trees.length, 1));
  const foliage = new THREE.InstancedMesh(geo.treeFoliage, FOLIAGE_MAT, Math.max(trees.length, 1));
  trees.forEach((t, i) => {
    const y = terrainHeight(t.x, t.z);
    q.setFromAxisAngle(up, t.ry); p.set(t.x, y - 0.05, t.z); s.setScalar(t.scale);
    m.compose(p, q, s);
    trunks.setMatrixAt(i, m); foliage.setMatrixAt(i, m);
    col.setHSL(0.27 + (Math.sin(i * 12.9) * 0.5 + 0.5) * 0.06, 0.38, 0.32 + (Math.sin(i * 7.3) * 0.5 + 0.5) * 0.1);
    foliage.setColorAt(i, col);
    addCollider(t.x, t.z, TREE_COLLISION_RADIUS * t.scale, y, 4.5 * t.scale);
  });
  trunks.count = foliage.count = trees.length;
  scene.add(trunks, foliage);

  // rocks
  const rockMesh = new THREE.InstancedMesh(geo.rock, ROCK_INSTANCE_MAT, Math.max(rocks.length, 1));
  rocks.forEach((r, i) => {
    const y = terrainHeight(r.x, r.z);
    q.setFromAxisAngle(up, r.ry); p.set(r.x, y - 0.1 * r.scale, r.z); s.set(r.scale, r.scale * 0.8, r.scale * (0.85 + (i % 3) * 0.12));
    m.compose(p, q, s);
    rockMesh.setMatrixAt(i, m);
    col.setHSL(0.1, 0.05, 0.5 + (Math.sin(i * 5.1) * 0.5 + 0.5) * 0.15);
    rockMesh.setColorAt(i, col);
    addCollider(r.x, r.z, ROCK_COLLISION_RADIUS * r.scale, y, 1.3 * r.scale);
  });
  rockMesh.count = rocks.length;
  scene.add(rockMesh);

  // buildings + crates (few, so plain groups are fine)
  for (const b of layout.props) {
    if (b.type === 'building') {
      const g = buildBuildingGroup(b.size);
      const y = terrainHeight(b.x, b.z);
      g.position.set(b.x, y, b.z); g.rotation.y = b.ry;
      scene.add(g);
      addCollider(b.x, b.z, g.userData.collisionRadius, y, 4);
    } else if (b.type === 'crate') {
      const g = buildCrateGroup();
      const y = terrainHeight(b.x, b.z);
      g.position.set(b.x, y, b.z); g.rotation.y = b.ry;
      scene.add(g);
      addCollider(b.x, b.z, g.userData.collisionRadius, y, 0.8);
    }
  }
}

/** Push a circle (x, z, radius) out of every collider. Returns the corrected position. */
export function resolveCollisions(x, z, radius, feetY) {
  for (let i = 0; i < world.colliders.length; i++) {
    const c = world.colliders[i];
    if (feetY > c.y0 + c.h) continue; // jumped over it (crates, rocks)
    const dx = x - c.x, dz = z - c.z;
    const min = radius + c.r;
    const d2 = dx * dx + dz * dz;
    if (d2 < min * min) {
      const d = Math.sqrt(d2) || 0.0001;
      x = c.x + (dx / d) * min;
      z = c.z + (dz / d) * min;
    }
  }
  return { x, z };
}

/**
 * Distance along a 3D ray to the first prop that blocks it, or Infinity.
 * Used so bullets cannot pass through trees, rocks and walls.
 */
export function rayObstruction(ox, oy, oz, dx, dy, dz, maxDist) {
  const a = dx * dx + dz * dz;
  if (a < 1e-8) return Infinity;
  let best = Infinity;
  for (let i = 0; i < world.colliders.length; i++) {
    const c = world.colliders[i];
    const fx = ox - c.x, fz = oz - c.z;
    const b = 2 * (fx * dx + fz * dz);
    const cc = fx * fx + fz * fz - c.r * c.r;
    const disc = b * b - 4 * a * cc;
    if (disc < 0) continue;
    const sq = Math.sqrt(disc);
    let t = (-b - sq) / (2 * a);
    if (t < 0) t = (-b + sq) / (2 * a);
    if (t < 0 || t > maxDist || t >= best) continue;
    const y = oy + dy * t;
    if (y < c.y0 + c.h && y > c.y0 - 0.5) best = t;
  }
  return best;
}

// ================================= pickups ================================

export function clearPickups() {
  for (const p of world.pickups.values()) world.scene.remove(p.group);
  world.pickups.clear();
}

export function addPickup(id, type, x, z) {
  const group = buildPickupMarker(type);
  const baseY = terrainHeight(x, z);
  group.position.set(x, baseY, z);
  world.scene.add(group);
  world.pickups.set(id, { group, type, baseY, x, z });
}

export function removePickup(id) {
  const p = world.pickups.get(id);
  if (!p) return;
  world.scene.remove(p.group);
  world.pickups.delete(id);
}

export function animatePickups(t) {
  for (const p of world.pickups.values()) {
    const g = p.group;
    g.userData.spinPart.rotation.y = t * 1.8;
    g.userData.spinPart.position.y = 1.0 + Math.sin(t * 2.2 + p.x) * 0.12;
    g.userData.ringPart.scale.setScalar(1 + Math.sin(t * 3 + p.z) * 0.06);
  }
}

// ================================ zone wall ===============================

function buildZoneWall(scene, layout) {
  const geo = new THREE.CylinderGeometry(1, 1, 90, 56, 1, true);
  const wall = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
    color: 0xd94f4f, transparent: true, opacity: 0.2, side: THREE.DoubleSide, depthWrite: false, fog: false
  }));
  wall.position.set(layout.zone.center.x, 30, layout.zone.center.z);
  wall.scale.set(layout.zone.initialRadius, 1, layout.zone.initialRadius);
  scene.add(wall);
  world.zoneWall = wall;
  world.zoneRadius = layout.zone.initialRadius;
}

export function setZoneRadius(r) {
  world.zoneRadius = r;
  if (world.zoneWall) world.zoneWall.scale.set(r, 1, r);
}
