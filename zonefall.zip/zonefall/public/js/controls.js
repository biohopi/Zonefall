/**
 * controls.js — unified input. Touch (virtual joystick + drag-to-look + buttons,
 * no gyroscope) and desktop (WASD + mouse look + click to fire) both write
 * into the same `input` object that game.js reads every frame.
 */
export const input = {
  moveX: 0,          // strafe  -1..1 (right positive)
  moveY: 0,          // forward -1..1 (forward positive)
  lookDX: 0,         // accumulated look delta (radians) since last frame
  lookDY: 0,
  fireHeld: false,
  firePressed: false, // edge: set on press, consumed by game.js
  jumpPressed: false,
  reloadPressed: false,
  switchPressed: false,
  sprint: false
};

export const isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

const LOOK_SENS_TOUCH = 0.0052;
const LOOK_SENS_MOUSE = 0.0023;
const $ = (id) => document.getElementById(id);

let enabled = false;
export function setControlsEnabled(on) {
  enabled = on;
  if (!on) resetInput();
}
export function resetInput() {
  input.moveX = input.moveY = 0; input.fireHeld = false; input.sprint = false;
  input.firePressed = input.jumpPressed = input.reloadPressed = input.switchPressed = false;
  const stick = $('joystick-move-stick');
  if (stick) stick.style.transform = '';
  const sp = $('btn-touch-sprint');
  if (sp) sp.classList.remove('engaged');
  keys.clear();
}

// ================================ touch ====================================

function initTouch() {
  $('touch-controls').classList.remove('hidden');

  // --- virtual joystick (fixed position, left thumb) ---
  const zone = $('joystick-move-zone'), stick = $('joystick-move-stick');
  let joyId = null;
  const MAX = 46;
  function joyMove(e) {
    const r = zone.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    const d = Math.hypot(dx, dy);
    if (d > MAX) { dx = (dx / d) * MAX; dy = (dy / d) * MAX; }
    stick.style.transform = `translate(${dx}px, ${dy}px)`;
    const nx = dx / MAX, ny = dy / MAX;
    input.moveX = Math.abs(nx) < 0.12 ? 0 : nx;
    input.moveY = Math.abs(ny) < 0.12 ? 0 : -ny;
    // pushing the stick nearly all the way forward auto-sprints
    if (ny < -0.92 && !input.sprint) setSprint(true);
  }
  function joyEnd(e) {
    if (e.pointerId !== joyId) return;
    joyId = null; input.moveX = input.moveY = 0; stick.style.transform = '';
  }
  zone.addEventListener('pointerdown', (e) => { if (!enabled || joyId !== null) return; joyId = e.pointerId; zone.setPointerCapture(e.pointerId); joyMove(e); e.preventDefault(); });
  zone.addEventListener('pointermove', (e) => { if (e.pointerId === joyId) joyMove(e); });
  zone.addEventListener('pointerup', joyEnd);
  zone.addEventListener('pointercancel', joyEnd);

  // --- look: drag on the right side, and also while holding FIRE ---
  const look = $('look-zone');
  let lookId = null, lx = 0, ly = 0;
  look.addEventListener('pointerdown', (e) => { if (!enabled || lookId !== null) return; lookId = e.pointerId; lx = e.clientX; ly = e.clientY; look.setPointerCapture(e.pointerId); e.preventDefault(); });
  look.addEventListener('pointermove', (e) => {
    if (e.pointerId !== lookId) return;
    input.lookDX += (e.clientX - lx) * LOOK_SENS_TOUCH; input.lookDY += (e.clientY - ly) * LOOK_SENS_TOUCH;
    lx = e.clientX; ly = e.clientY;
  });
  const lookEnd = (e) => { if (e.pointerId === lookId) lookId = null; };
  look.addEventListener('pointerup', lookEnd);
  look.addEventListener('pointercancel', lookEnd);

  // --- action buttons ---
  const fire = $('btn-touch-fire');
  let fireId = null, fx = 0, fy = 0;
  fire.addEventListener('pointerdown', (e) => {
    if (!enabled || fireId !== null) return;
    fireId = e.pointerId; fx = e.clientX; fy = e.clientY; fire.setPointerCapture(e.pointerId);
    input.fireHeld = true; input.firePressed = true; e.preventDefault();
  });
  fire.addEventListener('pointermove', (e) => {
    if (e.pointerId !== fireId) return;
    input.lookDX += (e.clientX - fx) * LOOK_SENS_TOUCH; input.lookDY += (e.clientY - fy) * LOOK_SENS_TOUCH;
    fx = e.clientX; fy = e.clientY;
  });
  const fireEnd = (e) => { if (e.pointerId !== fireId) return; fireId = null; input.fireHeld = false; };
  fire.addEventListener('pointerup', fireEnd);
  fire.addEventListener('pointercancel', fireEnd);

  const tap = (id, key) => $(id).addEventListener('pointerdown', (e) => { if (enabled) input[key] = true; e.preventDefault(); });
  tap('btn-touch-jump', 'jumpPressed');
  tap('btn-touch-reload', 'reloadPressed');
  tap('btn-touch-weapon-switch', 'switchPressed');

  $('btn-touch-sprint').addEventListener('pointerdown', (e) => { if (enabled) setSprint(!input.sprint); e.preventDefault(); });

  // block page scroll / pinch / context menu while playing
  const screen = $('screen-game');
  screen.addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });
  screen.addEventListener('contextmenu', (e) => e.preventDefault());
}

function setSprint(on) {
  input.sprint = on;
  $('btn-touch-sprint').classList.toggle('engaged', on);
}
export function clearSprint() { setSprint(false); }

// ================================ desktop ===================================

const keys = new Set();

function initDesktop(canvasContainer) {
  window.addEventListener('keydown', (e) => {
    if (!enabled) return;
    if (e.repeat) return;
    keys.add(e.code);
    if (e.code === 'Space') input.jumpPressed = true;
    if (e.code === 'KeyR') input.reloadPressed = true;
    if (e.code === 'KeyQ' || e.code === 'Tab') { input.switchPressed = true; e.preventDefault(); }
    if (e.code === 'Space') e.preventDefault();
    refreshKeys();
  });
  window.addEventListener('keyup', (e) => { keys.delete(e.code); refreshKeys(); });
  function refreshKeys() {
    input.moveX = (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0);
    input.moveY = (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0) - (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0);
    input.sprint = keys.has('ShiftLeft') || keys.has('ShiftRight');
  }
  canvasContainer.addEventListener('mousedown', (e) => {
    if (!enabled) return;
    if (document.pointerLockElement !== canvasContainer) { canvasContainer.requestPointerLock && canvasContainer.requestPointerLock(); return; }
    if (e.button === 0) { input.fireHeld = true; input.firePressed = true; }
  });
  window.addEventListener('mouseup', (e) => { if (e.button === 0) input.fireHeld = false; });
  window.addEventListener('mousemove', (e) => {
    if (!enabled || document.pointerLockElement !== canvasContainer) return;
    input.lookDX += e.movementX * LOOK_SENS_MOUSE; input.lookDY += e.movementY * LOOK_SENS_MOUSE;
  });
}

export function exitPointerLock() { if (document.exitPointerLock) document.exitPointerLock(); }

export function initControls(canvasContainer) {
  if (isTouchDevice) initTouch();
  initDesktop(canvasContainer); // harmless on phones, and lets a touch laptop use a keyboard
}
