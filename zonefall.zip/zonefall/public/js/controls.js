/**
 * controls.js — unified input. Touch (virtual joystick + drag-to-look + buttons,
 * no gyroscope) and desktop (WASD + mouse look + click to fire) both write
 * into the same `input` object that game.js reads every frame.
 */
export const input = {
  moveX: 0,          // strafe  -1..1 (right positive)
  moveY: 0,          // forward -1..1 (forward positive)
  lookDX: 0,         // accumulated look delta (radians) since last frame
  lookDY: 0,
  fireHeld: false,
  firePressed: false, // edge: set on press, consumed by game.js
  jumpPressed: false,
  reloadPressed: false,
  switchPressed: false,
  sprint: false
};

export const isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

const LOOK_SENS_TOUCH = 0.0052;
const LOOK_SENS_MOUSE = 0.0023;
const $ = (id) => document.getElementById(id);

let enabled = false;
let layoutEditing = false;
let selectedLayoutId = null;
let layoutEditorInitialized = false;
const LAYOUT_KEY = 'zonefall.touch-layout.v1';
const layoutTargets = ['joystick-move-zone', 'btn-touch-weapon-switch', 'btn-touch-reload', 'btn-touch-jump', 'btn-touch-fire', 'btn-touch-sprint'];
const orientationName = () => window.matchMedia('(orientation: portrait)').matches ? 'portrait' : 'landscape';
function readLayouts() { try { return JSON.parse(localStorage.getItem(LAYOUT_KEY) || '{}'); } catch { return {}; } }
function writeLayouts(v) { localStorage.setItem(LAYOUT_KEY, JSON.stringify(v)); }
function applyLayout() {
  const saved = readLayouts()[orientationName()] || {};
  for (const id of layoutTargets) {
    const el = $(id); if (!el) continue;
    el.style.position = ''; el.style.left = el.style.top = el.style.right = el.style.bottom = '';
    const pos = saved[id];
    if (pos) { el.style.position = 'absolute'; el.style.left = `${pos.x * 100}%`; el.style.top = `${pos.y * 100}%`; el.style.right = 'auto'; el.style.bottom = 'auto'; }
  }
  const label = $('touch-layout-orientation');
  if (label) label.textContent = orientationName();
}
function captureLayout() {
  const out = {};
  for (const id of layoutTargets) { const el = $(id); if (!el) continue; const r = el.getBoundingClientRect(); out[id] = { x: Math.max(0, Math.min(1, r.left / innerWidth)), y: Math.max(0, Math.min(1, r.top / innerHeight)) }; }
  const all = readLayouts(); all[orientationName()] = out; writeLayouts(all);
}
function clearLayout() { const all = readLayouts(); delete all[orientationName()]; writeLayouts(all); applyLayout(); }
function setLayoutEditing(on) {
  layoutEditing = on; selectedLayoutId = null;
  document.body.classList.toggle('layout-editing', on);
  enabled = !on;
  document.querySelectorAll('[data-layout-id].layout-selected').forEach((el) => el.classList.remove('layout-selected'));
  if (!on) { resetInput(); applyLayout(); }
}
export function initLayoutEditor() {
  if (layoutEditorInitialized) return;
  const panel = $('touch-layout-panel');
  if (!panel) return;
  layoutEditorInitialized = true;
  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement || document.webkitFullscreenElement) {
        if (document.exitFullscreen) await document.exitFullscreen();
        else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
        return;
      }
      const el = document.documentElement;
      if (el.requestFullscreen) await el.requestFullscreen({ navigationUI: 'hide' });
      else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
      else if (document.body.webkitRequestFullscreen) document.body.webkitRequestFullscreen();
      else throw new Error('Fullscreen is not supported by this browser');
    } catch (err) {
      console.warn('[zonefall] fullscreen unavailable:', err?.message || err);
    }
  };
  for (const id of ['btn-lobby-fullscreen', 'btn-room-fullscreen']) {
    const fullscreen = $(id);
    if (fullscreen) fullscreen.addEventListener('click', toggleFullscreen);
  }
  const closeEditor = () => {
    setLayoutEditing(false);
    panel.classList.add('hidden');
    window.dispatchEvent(new CustomEvent('zonefall-layout-close'));
  };
  $('btn-touch-layout-save').addEventListener('click', () => { captureLayout(); setLayoutEditing(false); });
  $('btn-touch-layout-close').addEventListener('click', closeEditor);
  for (const id of layoutTargets) {
    const el = $(id); if (!el) continue; let drag = null;
    el.addEventListener('pointerdown', (e) => {
      if (!layoutEditing) return;
      selectedLayoutId = id;
      // Right-side controls are flex items in gameplay; make the selected control
      // independently positionable while editing.
      el.style.position = 'absolute';
      document.querySelectorAll('[data-layout-id].layout-selected').forEach((x) => x.classList.remove('layout-selected'));
      el.classList.add('layout-selected');
      drag = { id: e.pointerId, x: e.clientX - el.getBoundingClientRect().left, y: e.clientY - el.getBoundingClientRect().top };
      if (el.setPointerCapture) el.setPointerCapture(e.pointerId);
      e.preventDefault(); e.stopPropagation();
    });
    el.addEventListener('pointermove', (e) => {
      if (!drag || drag.id !== e.pointerId) return;
      const x = Math.max(0, Math.min(innerWidth - el.offsetWidth, e.clientX - drag.x));
      const y = Math.max(0, Math.min(innerHeight - el.offsetHeight, e.clientY - drag.y));
      el.style.left = `${x}px`; el.style.top = `${y}px`; el.style.right = el.style.bottom = 'auto';
      e.preventDefault(); e.stopPropagation();
    });
    const end = (e) => { if (drag && drag.id === e.pointerId) drag = null; };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  }
  const editorSurface = $('layout-editor-surface');
  editorSurface.addEventListener('pointerdown', (e) => {
    if (!layoutEditing || !selectedLayoutId || e.target.closest('#touch-layout-panel, [data-layout-id]')) return;
    const el = $(selectedLayoutId); if (!el) return;
    el.style.position = 'absolute';
    const x = Math.max(0, Math.min(innerWidth - el.offsetWidth, e.clientX - el.offsetWidth / 2));
    const y = Math.max(0, Math.min(innerHeight - el.offsetHeight, e.clientY - el.offsetHeight / 2));
    el.style.left = `${x}px`; el.style.top = `${y}px`; el.style.right = el.style.bottom = 'auto';
  }, true);
  window.addEventListener('orientationchange', () => setTimeout(applyLayout, 120));
  window.addEventListener('resize', () => { if (!layoutEditing) applyLayout(); });
  applyLayout();
}

export function openLayoutEditor() {
  initLayoutEditor();
  const panel = $('touch-layout-panel');
  const root = $('controls-root');
  if (root) root.classList.add('active');
  const touchControls = $('touch-controls');
  if (touchControls) touchControls.classList.remove('hidden');
  if (panel) { panel.classList.remove('hidden'); applyLayout(); }
  // Open directly in edit mode: dragging and tap-to-place are immediately available.
  setLayoutEditing(true);
}

export function setControlsEnabled(on) {
  enabled = on;
  if (on) applyLayout();
  if (!on) resetInput();
}
export function resetInput() {
  input.moveX = input.moveY = 0; input.fireHeld = false; input.sprint = false;
  input.firePressed = input.jumpPressed = input.reloadPressed = input.switchPressed = false;
  const stick = $('joystick-move-stick');
  if (stick) stick.style.transform = '';
  const sp = $('btn-touch-sprint');
  if (sp) sp.classList.remove('engaged');
  keys.clear();
}

// ================================ touch ====================================

function initTouch() {
  $('touch-controls').classList.remove('hidden');
  initLayoutEditor();

  // --- virtual joystick (fixed position, left thumb) ---
  const zone = $('joystick-move-zone'), stick = $('joystick-move-stick');
  let joyId = null;
  const MAX = 46;
  function joyMove(e) {
    const r = zone.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    const d = Math.hypot(dx, dy);
    if (d > MAX) { dx = (dx / d) * MAX; dy = (dy / d) * MAX; }
    stick.style.transform = `translate(${dx}px, ${dy}px)`;
    const nx = dx / MAX, ny = dy / MAX;
    input.moveX = Math.abs(nx) < 0.12 ? 0 : nx;
    input.moveY = Math.abs(ny) < 0.12 ? 0 : -ny;
    // pushing the stick nearly all the way forward auto-sprints
    if (ny < -0.92 && !input.sprint) setSprint(true);
  }
  function joyEnd(e) {
    if (e.pointerId !== joyId) return;
    joyId = null; input.moveX = input.moveY = 0; stick.style.transform = '';
  }
  zone.addEventListener('pointerdown', (e) => { if (!enabled || joyId !== null) return; joyId = e.pointerId; zone.setPointerCapture(e.pointerId); joyMove(e); e.preventDefault(); });
  zone.addEventListener('pointermove', (e) => { if (e.pointerId === joyId) joyMove(e); });
  zone.addEventListener('pointerup', joyEnd);
  zone.addEventListener('pointercancel', joyEnd);

  // --- look: drag on the right side, and also while holding FIRE ---
  const look = $('look-zone');
  let lookId = null, lx = 0, ly = 0;
  look.addEventListener('pointerdown', (e) => { if (!enabled || lookId !== null) return; lookId = e.pointerId; lx = e.clientX; ly = e.clientY; look.setPointerCapture(e.pointerId); e.preventDefault(); });
  look.addEventListener('pointermove', (e) => {
    if (e.pointerId !== lookId) return;
    input.lookDX += (e.clientX - lx) * LOOK_SENS_TOUCH; input.lookDY += (e.clientY - ly) * LOOK_SENS_TOUCH;
    lx = e.clientX; ly = e.clientY;
  });
  const lookEnd = (e) => { if (e.pointerId === lookId) lookId = null; };
  look.addEventListener('pointerup', lookEnd);
  look.addEventListener('pointercancel', lookEnd);

  // --- action buttons ---
  const fire = $('btn-touch-fire');
  let fireId = null, fx = 0, fy = 0;
  fire.addEventListener('pointerdown', (e) => {
    if (!enabled || fireId !== null) return;
    fireId = e.pointerId; fx = e.clientX; fy = e.clientY; fire.setPointerCapture(e.pointerId);
    input.fireHeld = true; input.firePressed = true; e.preventDefault();
  });
  fire.addEventListener('pointermove', (e) => {
    if (e.pointerId !== fireId) return;
    input.lookDX += (e.clientX - fx) * LOOK_SENS_TOUCH; input.lookDY += (e.clientY - fy) * LOOK_SENS_TOUCH;
    fx = e.clientX; fy = e.clientY;
  });
  const fireEnd = (e) => { if (e.pointerId !== fireId) return; fireId = null; input.fireHeld = false; };
  fire.addEventListener('pointerup', fireEnd);
  fire.addEventListener('pointercancel', fireEnd);

  const tap = (id, key) => $(id).addEventListener('pointerdown', (e) => { if (enabled) input[key] = true; e.preventDefault(); });
  tap('btn-touch-jump', 'jumpPressed');
  tap('btn-touch-reload', 'reloadPressed');
  tap('btn-touch-weapon-switch', 'switchPressed');

  $('btn-touch-sprint').addEventListener('pointerdown', (e) => { if (enabled) setSprint(!input.sprint); e.preventDefault(); });

  // block page scroll / pinch / context menu while playing
  const screen = $('screen-game');
  screen.addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });
  screen.addEventListener('contextmenu', (e) => e.preventDefault());
}

function setSprint(on) {
  input.sprint = on;
  $('btn-touch-sprint').classList.toggle('engaged', on);
}
export function clearSprint() { setSprint(false); }

// ================================ desktop ===================================

const keys = new Set();

function initDesktop(canvasContainer) {
  window.addEventListener('keydown', (e) => {
    if (!enabled) return;
    if (e.repeat) return;
    keys.add(e.code);
    if (e.code === 'Space') input.jumpPressed = true;
    if (e.code === 'KeyR') input.reloadPressed = true;
    if (e.code === 'KeyQ' || e.code === 'Tab') { input.switchPressed = true; e.preventDefault(); }
    if (e.code === 'Space') e.preventDefault();
    refreshKeys();
  });
  window.addEventListener('keyup', (e) => { keys.delete(e.code); refreshKeys(); });
  function refreshKeys() {
    input.moveX = (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0);
    input.moveY = (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0) - (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0);
    input.sprint = keys.has('ShiftLeft') || keys.has('ShiftRight');
  }
  canvasContainer.addEventListener('mousedown', (e) => {
    if (!enabled) return;
    if (document.pointerLockElement !== canvasContainer) { canvasContainer.requestPointerLock && canvasContainer.requestPointerLock(); return; }
    if (e.button === 0) { input.fireHeld = true; input.firePressed = true; }
  });
  window.addEventListener('mouseup', (e) => { if (e.button === 0) input.fireHeld = false; });
  window.addEventListener('mousemove', (e) => {
    if (!enabled || document.pointerLockElement !== canvasContainer) return;
    input.lookDX += e.movementX * LOOK_SENS_MOUSE; input.lookDY += e.movementY * LOOK_SENS_MOUSE;
  });
}

export function exitPointerLock() { if (document.exitPointerLock) document.exitPointerLock(); }

export function initControls(canvasContainer) {
  initLayoutEditor();
  if (isTouchDevice) initTouch();
  initDesktop(canvasContainer); // harmless on phones, and lets a touch laptop use a keyboard
}
