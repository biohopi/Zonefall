/**
 * net.js — auth REST calls + the single authenticated Socket.io connection.
 * Session token lives in localStorage so a page reload keeps you logged in.
 */
const TOKEN_KEY = 'zonefall.token';
const USER_KEY = 'zonefall.user';

export const session = {
  token: null,
  username: null,
  load() {
    try { this.token = localStorage.getItem(TOKEN_KEY); this.username = localStorage.getItem(USER_KEY); } catch (e) { /* private mode */ }
  },
  save(token, username) {
    this.token = token; this.username = username;
    try { localStorage.setItem(TOKEN_KEY, token); localStorage.setItem(USER_KEY, username); } catch (e) { /* ignore */ }
  },
  clear() {
    this.token = null; this.username = null;
    try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); } catch (e) { /* ignore */ }
  }
};

async function post(url, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  let res;
  try {
    res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body || {}) });
  } catch (e) {
    throw new Error('Cannot reach the server. Check your connection.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}

export const api = {
  register: (username, password) => post('/api/register', { username, password }),
  login: (username, password) => post('/api/login', { username, password }),
  logout: () => post('/api/logout', {}, session.token).catch(() => {}),
  async me() {
    if (!session.token) throw new Error('no token');
    const res = await fetch('/api/me', { headers: { Authorization: 'Bearer ' + session.token } });
    if (!res.ok) throw new Error('expired');
    return res.json();
  }
};

let socket = null;

export function getSocket() { return socket; }

/** Opens (or reuses) the socket. Resolves when connected, rejects on auth failure. */
export function connectSocket() {
  return new Promise((resolve, reject) => {
    if (socket && socket.connected) return resolve(socket);
    if (socket) { socket.disconnect(); socket = null; }
    // eslint-disable-next-line no-undef
    socket = io({ auth: { token: session.token }, transports: ['websocket', 'polling'] });
    socket.once('connect', () => resolve(socket));
    socket.once('connect_error', (err) => reject(err));
  });
}

export function disconnectSocket() {
  if (socket) { socket.disconnect(); socket = null; }
}
