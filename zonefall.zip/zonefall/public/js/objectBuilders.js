/**
 * objectBuilders.js
 * -----------------------------------------------------------------------
 * Every visible thing in Zonefall is assembled here, part by part, from
 * Three.js primitive geometry — no imported models, no textures, no
 * external art of any kind. Flat-shaded Lambert materials on low-vertex
 * primitives are what give the "low setting, high performance, good
 * looking" result: cheap to light, cheap to render, and the faceted look
 * reads as a deliberate style rather than a placeholder.
 *
 * Geometries and materials are created ONCE at module load and reused
 * (shared) across every instance — building a tree does not allocate a
 * new tree geometry, it reuses the one built here.
 */
import * as THREE from 'three';

// ============================== materials ================================

function lam(color, extra) {
  return new THREE.MeshLambertMaterial(Object.assign({ color, flatShading: true }, extra || {}));
}

export const MAT = {
  bark: lam(0x5b4632),
  rock: lam(0x8a8a82),
  buildingWall: lam(0xcfc9a8),
  buildingRoof: lam(0x6a4f3a),
  doorway: lam(0x1c1712, { side: THREE.DoubleSide }),
  crateBody: lam(0x8a6a3f),
  crateLid: lam(0xa9824c),
  gunDark: lam(0x2a2a28),
  gunGrip: lam(0x3a342c),
  rifleAccent: lam(0xc97a3d),
  shotgunAccent: lam(0x7a8a6a),
  healthIcon: lam(0xe5503f),
  rifleIcon: lam(0xd9b44a),
  shotgunIcon: lam(0x5b7fbf),
  pickupRing: lam(0xece7da, { transparent: true, opacity: 0.8 }),
  shadowBlob: new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.32, depthWrite: false }),
  strap: lam(0x33302a),
  eyes: lam(0x161c17)
};

// Foliage and rocks get a slightly different colour per instance via
// InstancedMesh.setColorAt. The instance colour multiplies the material
// colour, so the material is white and the instance colour is the real tint.
// (Do not turn on vertexColors here: these geometries have no colour attribute.)
export const FOLIAGE_MAT = lam(0xffffff);
export const ROCK_INSTANCE_MAT = lam(0xffffff);

const bodyMaterialCache = new Map();
function bodyMaterialFor(colorHex) {
  if (!bodyMaterialCache.has(colorHex)) bodyMaterialCache.set(colorHex, lam(colorHex));
  return bodyMaterialCache.get(colorHex);
}

export const PLAYER_COLORS = [
  0xE2593A, 0x3E8E7E, 0xD9B44A, 0x5B7FBF, 0xB15FA6,
  0x7FA650, 0xC97A3D, 0x4F6B8A, 0x9C5B3C, 0x6FA8A0
];
export function colorForIndex(i) { return PLAYER_COLORS[((i % PLAYER_COLORS.length) + PLAYER_COLORS.length) % PLAYER_COLORS.length]; }

// ================================ shared geometry =========================

const HEAD_GEO = new THREE.BoxGeometry(0.34, 0.34, 0.34);
const TORSO_GEO = new THREE.BoxGeometry(0.5, 0.62, 0.3);
const ARM_GEO = new THREE.BoxGeometry(0.15, 0.52, 0.15);
const LEG_GEO = new THREE.BoxGeometry(0.19, 0.6, 0.19);
const BACKPACK_GEO = new THREE.BoxGeometry(0.38, 0.32, 0.16);
const SHADOW_GEO = new THREE.CircleGeometry(0.46, 14);

const TREE_TRUNK_GEO = new THREE.CylinderGeometry(0.09, 0.15, 1.1, 6);
TREE_TRUNK_GEO.translate(0, 0.55, 0);
const TREE_FOLIAGE_GEO = new THREE.IcosahedronGeometry(0.72, 0);
TREE_FOLIAGE_GEO.translate(0, 1.45, 0);

const ROCK_GEO = new THREE.IcosahedronGeometry(0.6, 0);
ROCK_GEO.translate(0, 0.58, 0);

export const TREE_COLLISION_RADIUS = 0.32;
export const ROCK_COLLISION_RADIUS = 0.58;

export function geometries() {
  return {
    treeTrunk: TREE_TRUNK_GEO, treeFoliage: TREE_FOLIAGE_GEO, rock: ROCK_GEO
  };
}

// ================================ character ===============================

/**
 * Builds a low-poly humanoid from eight separate parts (head, torso,
 * backpack, two shoulder-pivoted arms, two hip-pivoted legs) plus a soft
 * contact-shadow blob. Returns handles to every part so the caller can
 * drive a simple procedural walk cycle and tag hit locations.
 */
export function buildCharacter(colorHex) {
  const bodyMat = bodyMaterialFor(colorHex);
  const group = new THREE.Group();

  const torso = new THREE.Mesh(TORSO_GEO, bodyMat);
  torso.position.y = 1.12;
  torso.userData.hitPart = 'body';
  group.add(torso);

  const head = new THREE.Mesh(HEAD_GEO, bodyMat);
  head.position.y = 1.61;
  head.userData.hitPart = 'head';
  group.add(head);

  const backpack = new THREE.Mesh(BACKPACK_GEO, MAT.strap);
  backpack.position.set(0, 1.1, 0.21);
  backpack.userData.hitPart = 'body';
  group.add(backpack);

  function shoulder(sign) {
    const pivot = new THREE.Group();
    pivot.position.set(sign * 0.325, 1.39, 0);
    const arm = new THREE.Mesh(ARM_GEO, bodyMat);
    arm.position.y = -0.26;
    arm.userData.hitPart = 'body';
    pivot.add(arm);
    group.add(pivot);
    return pivot;
  }
  function hip(sign) {
    const pivot = new THREE.Group();
    pivot.position.set(sign * 0.15, 0.6, 0);
    const leg = new THREE.Mesh(LEG_GEO, bodyMat);
    leg.position.y = -0.3;
    leg.userData.hitPart = 'body';
    pivot.add(leg);
    group.add(pivot);
    return pivot;
  }

  const leftShoulder = shoulder(-1);
  const rightShoulder = shoulder(1);
  const leftHip = hip(-1);
  const rightHip = hip(1);

  // Weapon mount stays parented to the torso (not the swinging arm) so the
  // held weapon stays level and aimable instead of flailing with the walk cycle.
  const weaponMount = new THREE.Group();
  weaponMount.position.set(0.3, 1.33, -0.08);
  group.add(weaponMount);

  const shadowBlob = new THREE.Mesh(SHADOW_GEO, MAT.shadowBlob);
  shadowBlob.rotation.x = -Math.PI / 2;
  shadowBlob.position.y = 0.015;
  group.add(shadowBlob);

  return {
    group,
    parts: { torso, head, backpack, leftShoulder, rightShoulder, leftHip, rightHip, weaponMount, shadowBlob }
  };
}

// ================================= weapons =================================

/** Builds a held-weapon model. Ids match the stats table in weapons.js. */
export function buildWeaponMesh(weaponId) {
  const group = new THREE.Group();
  if (weaponId === 'rifle') {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.13, 0.56), MAT.gunDark);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.3, 6), MAT.gunDark);
    barrel.rotation.z = Math.PI / 2; barrel.position.set(0, 0.01, -0.42);
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.22, 0.09), MAT.gunGrip);
    mag.position.set(0, -0.16, -0.04); mag.rotation.x = -0.32;
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.1, 0.22), MAT.gunDark);
    stock.position.set(0, -0.01, 0.37);
    const sight = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.06, 0.1), MAT.rifleAccent);
    sight.position.set(0, 0.095, -0.05);
    group.add(body, barrel, mag, stock, sight);
    group.userData.muzzleOffset = new THREE.Vector3(0, 0.01, -0.58);
  } else if (weaponId === 'shotgun') {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.15, 0.4), MAT.gunDark);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.32, 6), MAT.gunDark);
    barrel.rotation.z = Math.PI / 2; barrel.position.set(0, 0.02, -0.34);
    const pump = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 0.16), MAT.shotgunAccent);
    pump.position.set(0, -0.06, -0.2);
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.12, 0.2), MAT.gunDark);
    stock.position.set(0, -0.01, 0.29);
    group.add(body, barrel, pump, stock);
    group.userData.muzzleOffset = new THREE.Vector3(0, 0.02, -0.52);
  } else {
    // pistol (default / infinite ammo)
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.12, 0.26), MAT.gunDark);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.17, 0.09), MAT.gunGrip);
    grip.position.set(0, -0.13, -0.07); grip.rotation.x = 0.3;
    const slide = new THREE.Mesh(new THREE.BoxGeometry(0.085, 0.05, 0.22), MAT.gunDark);
    slide.position.set(0, 0.06, -0.01);
    group.add(body, grip, slide);
    group.userData.muzzleOffset = new THREE.Vector3(0, 0.03, -0.32);
  }
  group.userData.weaponId = weaponId;
  return group;
}

// ================================= pickups ==================================

/** A floating, slowly spinning marker for a ground pickup (weapon or health). */
export function buildPickupMarker(type) {
  const group = new THREE.Group();
  let icon;
  if (type === 'health') {
    const barA = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.14, 0.14), MAT.healthIcon);
    const barB = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.46), MAT.healthIcon);
    icon = new THREE.Group();
    icon.add(barA, barB);
  } else {
    const mat = type === 'rifle' ? MAT.rifleIcon : MAT.shotgunIcon;
    icon = new THREE.Mesh(new THREE.OctahedronGeometry(0.25, 0), mat);
  }
  icon.position.y = 1.0;
  group.add(icon);

  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.035, 6, 16), MAT.pickupRing);
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.03;
  group.add(ring);

  group.userData.spinPart = icon;
  group.userData.ringPart = ring;
  return group;
}

// ============================== static props ================================

const BUILDING_SIZES = {
  small: { w: 2.8, h: 2.2, d: 2.8 },
  medium: { w: 4.0, h: 2.6, d: 3.5 },
  large: { w: 5.5, h: 3.2, d: 4.5 }
};

export function buildBuildingGroup(size) {
  const dims = BUILDING_SIZES[size] || BUILDING_SIZES.medium;
  const group = new THREE.Group();

  const wall = new THREE.Mesh(new THREE.BoxGeometry(dims.w, dims.h, dims.d), MAT.buildingWall);
  wall.position.y = dims.h / 2;
  group.add(wall);

  const roofH = dims.h * 0.4;
  const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(dims.w, dims.d) * 0.72, roofH, 4), MAT.buildingRoof);
  roof.position.y = dims.h + roofH / 2;
  roof.rotation.y = Math.PI / 4;
  group.add(roof);

  const door = new THREE.Mesh(new THREE.PlaneGeometry(0.85, 1.6), MAT.doorway);
  door.position.set(0, 0.8, dims.d / 2 + 0.01);
  group.add(door);

  group.userData.collisionRadius = Math.max(dims.w, dims.d) * 0.56;
  group.userData.blocksMovement = true;
  return group;
}

export function buildCrateGroup() {
  const group = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.65, 0.75), MAT.crateBody);
  body.position.y = 0.325;
  const lid = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.1, 0.8), MAT.crateLid);
  lid.position.y = 0.7;
  group.add(body, lid);
  group.userData.collisionRadius = 0.56;
  group.userData.blocksMovement = true;
  return group;
}

/** Simple squashed cone — reads as an open parachute canopy during the drop-in. */
export function buildParachuteGroup(colorHex) {
  const group = new THREE.Group();
  const canopy = new THREE.Mesh(new THREE.ConeGeometry(1.1, 0.75, 8, 1, true), lam(colorHex, { side: THREE.DoubleSide }));
  canopy.position.y = 2.1;
  group.add(canopy);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(1.1, 0.03, 4, 8), MAT.strap);
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 1.73;
  group.add(rim);
  return group;
}
