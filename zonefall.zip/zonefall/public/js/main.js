/**
 * main.js — screens, auth, lobby, room, and the glue between Socket.io
 * events and the game module.
 */
import { session, api, connectSocket, disconnectSocket } from './net.js';
import { initGame, startRound, beginPlay, stopRound, endRound, netHandlers } from './game.js';
import { unlockAudio } from './audio.js';

const $ = (id) => document.getElementById(id);

let layout = null;
let gameReady = false;
let socket = null;
let room = null;            // { code, hostId, players: [{id, username, isHost}], lobbyReady }
let pendingRoomCode = (new URLSearchParams(location.search).get('room') || '').toUpperCase().slice(0, 5);

// ================================ helpers ==================================

function showScreen(name) {
  document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('active', s.id === 'screen-' + name));
}

function toast(msg, kind) {
  const t = document.createElement('div');
  t.className = 'toast' + (kind === 'bad' ? ' toast-bad' : kind === 'good' ? ' toast-good' : '');
  t.textContent = msg;
  $('toast-container').appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

function showError(id, msg) {
  const e = $(id);
  if (!msg) { e.classList.add('hidden'); e.textContent = ''; return; }
  e.textContent = msg;
  e.classList.remove('hidden');
}

function setBusy(btn, busy) { btn.disabled = busy; }

document.addEventListener('pointerdown', unlockAudio);

// ================================== auth ===================================

function switchAuthTab(which) {
  const login = which === 'login';
  $('auth-tab-login').classList.toggle('active', login);
  $('auth-tab-register').classList.toggle('active', !login);
  $('auth-tab-login').setAttribute('aria-selected', String(login));
  $('auth-tab-register').setAttribute('aria-selected', String(!login));
  $('form-login').classList.toggle('hidden', !login);
  $('form-register').classList.toggle('hidden', login);
  showError('auth-error', '');
}
$('auth-tab-login').addEventListener('click', () => switchAuthTab('login'));
$('auth-tab-register').addEventListener('click', () => switchAuthTab('register'));

$('form-login').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('btn-login-submit');
  setBusy(btn, true); showError('auth-error', '');
  try {
    const res = await api.login($('login-username').value.trim(), $('login-password').value);
    session.save(res.token, res.username);
    await enterLobby();
  } catch (err) { showError('auth-error', err.message); }
  setBusy(btn, false);
});

$('form-register').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('btn-register-submit');
  showError('auth-error', '');
  if ($('register-password').value !== $('register-password2').value) { showError('auth-error', 'Passwords do not match.'); return; }
  setBusy(btn, true);
  try {
    const res = await api.register($('register-username').value.trim(), $('register-password').value);
    session.save(res.token, res.username);
    await enterLobby();
  } catch (err) { showError('auth-error', err.message); }
  setBusy(btn, false);
});

$('btn-logout').addEventListener('click', async () => {
  if (room && socket) socket.emit('leaveRoom');
  room = null;
  await api.logout();
  disconnectSocket(); socket = null;
  session.clear();
  showScreen('auth');
});

// ================================== lobby ==================================

async function enterLobby() {
  try {
    socket = await connectSocket();
  } catch (err) {
    if (err && err.message === 'unauthorized') { session.clear(); showScreen('auth'); showError('auth-error', 'Session expired. Please log in again.'); return; }
    throw new Error('Could not connect to the game server.');
  }
  bindSocket(socket);
  $('lobby-username-display').textContent = session.username;
  showError('lobby-error', '');
  if (pendingRoomCode) { $('join-room-code-input').value = pendingRoomCode; toast('Room code ' + pendingRoomCode + ' is ready — tap Join.', 'good'); pendingRoomCode = ''; }
  showScreen('lobby');
}

$('btn-create-room').addEventListener('click', () => {
  showError('lobby-error', '');
  socket.emit('createRoom', { bots: !!$('enable-bots').checked }, (res) => {
    if (!res || !res.ok) return showError('lobby-error', (res && res.error) || 'Could not create a room.');
    enterRoom(res);
  });
});

function joinFromInput() {
  const code = $('join-room-code-input').value.trim().toUpperCase();
  if (code.length !== 5) return showError('lobby-error', 'Room codes are 5 characters.');
  showError('lobby-error', '');
  socket.emit('joinRoom', { code }, (res) => {
    if (!res || !res.ok) return showError('lobby-error', (res && res.error) || 'Could not join that room.');
    enterRoom(res);
  });
}
$('btn-join-room').addEventListener('click', joinFromInput);
$('join-room-code-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') joinFromInput(); });

// =================================== room ==================================

function enterRoom(res) {
  room = { code: res.code, hostId: res.hostId, players: res.players, lobbyReady: true };
  $('room-code-display').textContent = room.code;
  $('room-chat-log').innerHTML = '';
  renderRoom();
  showScreen('room');
}

function renderRoom() {
  if (!room) return;
  const list = $('room-player-list');
  list.innerHTML = '';
  for (const p of room.players) {
    const li = document.createElement('li');
    const left = document.createElement('span');
    left.textContent = p.username;
    if (p.id === room.hostId) { const b = document.createElement('span'); b.className = 'host-badge'; b.textContent = 'HOST'; left.appendChild(b); }
    if (p.id === socket.id) { const y = document.createElement('span'); y.className = 'you-badge'; y.textContent = '(you)'; left.appendChild(y); }
    li.appendChild(left);
    list.appendChild(li);
  }
  $('room-player-count').textContent = `(${room.players.length}/10)`;
  const isHost = room.hostId === socket.id;
  const start = $('btn-start-match');
  start.classList.toggle('hidden', !isHost);
  start.disabled = !room.lobbyReady;
  start.textContent = room.lobbyReady ? 'Start match' : 'Match wrapping up…';
  $('room-status-msg').textContent = isHost
    ? 'You are the host. Start the match when your squad is in.'
    : 'Waiting for the host to start the match…';
}

$('btn-copy-room-code').addEventListener('click', async () => {
  if (!room) return;
  const link = `${location.origin}/?room=${room.code}`;
  const text = `Join my Zonefall room: ${room.code}  ${link}`;
  try { await navigator.clipboard.writeText(text); toast('Invite copied. Send it to your friends.', 'good'); }
  catch (e) { toast('Room code: ' + room.code); }
});

$('btn-start-match').addEventListener('click', () => { if (room && room.lobbyReady) socket.emit('startMatch'); });

$('btn-leave-room').addEventListener('click', () => { socket.emit('leaveRoom'); room = null; showScreen('lobby'); });

function sendChat() {
  const input = $('room-chat-input');
  const text = input.value.trim();
  if (!text || !room) return;
  socket.emit('chatMessage', text);
  input.value = '';
}
$('btn-room-chat-send').addEventListener('click', sendChat);
$('room-chat-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendChat(); });

// ============================== socket events ==============================

let boundSocket = null;
function bindSocket(s) {
  if (boundSocket === s) return;
  boundSocket = s;

  s.on('roomPlayers', (players) => {
    if (!room) return;
    room.players = players;
    const host = players.find((p) => p.isHost);
    if (host) room.hostId = host.id;
    renderRoom();
  });
  s.on('newHost', (d) => { if (room) { room.hostId = d.hostId; renderRoom(); } });
  s.on('chatMessage', (m) => {
    const log = $('room-chat-log');
    const line = document.createElement('div');
    line.className = 'chat-line';
    const who = document.createElement('span'); who.className = 'who'; who.textContent = m.username + ': ';
    line.appendChild(who); line.appendChild(document.createTextNode(m.text));
    log.appendChild(line);
    log.scrollTop = log.scrollHeight;
  });

  s.on('matchStarting', async (d) => {
    if (!room) return;
    room.lobbyReady = false;
    try { await ensureGame(); } catch (err) { toast('Could not start the 3D view on this device.', 'bad'); return; }
    const names = new Map(room.players.map((p) => [p.id, p.username]));
    showScreen('game');
    startRound({ socket: s, myId: s.id, spawns: d.spawns, pickups: d.pickups, names, countdownSec: d.countdownSec });
  });
  s.on('matchStarted', (d) => beginPlay(d.startedAt));

  for (const name of Object.keys(netHandlers)) s.on(name, (d) => netHandlers[name](d));

  s.on('matchEnded', (d) => {
    endRound();
    showResults(d);
  });
  s.on('backToLobby', () => { if (room) { room.lobbyReady = true; renderRoom(); } });

  s.on('disconnect', () => {
    if (!session.token) return;
    stopRound();
    room = null;
    toast('Connection lost. Reconnecting…', 'bad');
    showScreen('lobby');
  });
  s.on('connect_error', (err) => {
    if (err && err.message === 'unauthorized') { session.clear(); disconnectSocket(); boundSocket = null; showScreen('auth'); showError('auth-error', 'Session expired. Please log in again.'); }
  });
}

// ================================== game ===================================

async function ensureGame() {
  if (gameReady) return;
  if (!layout) layout = await (await fetch('shared/mapLayout.json')).json();
  initGame($('game-canvas-container'), layout);
  gameReady = true;
}

$('btn-game-leave').addEventListener('click', () => {
  if (!confirm('Leave the match?')) return;
  socket.emit('leaveRoom');
  stopRound();
  room = null;
  showScreen('lobby');
});

function showResults(d) {
  setTimeout(() => {
    if (!room) return;
    const mine = session.username;
    $('end-title').textContent = d.winner === mine ? 'LAST SIGNAL STANDING' : (d.winner ? d.winner + ' wins' : 'Match over');
    const box = $('end-stats');
    box.innerHTML = '';
    for (const r of d.results) {
      const row = document.createElement('div');
      row.className = 'stat-row' + (r.username === mine ? ' you' : '');
      const a = document.createElement('span'); a.textContent = `#${r.placement}  ${r.username}`;
      const b = document.createElement('span'); b.textContent = `${r.kills} ${r.kills === 1 ? 'kill' : 'kills'}`;
      row.appendChild(a); row.appendChild(b);
      box.appendChild(row);
    }
    stopRound();
    showScreen('end');
  }, 1800);
}

$('btn-return-lobby').addEventListener('click', () => {
  if (!room) { showScreen('lobby'); return; }
  renderRoom();
  showScreen('room');
});

// ================================= boot ====================================

(async function boot() {
  session.load();
  if (session.token) {
    try {
      await api.me();
      await enterLobby();
      return;
    } catch (e) { session.clear(); }
  }
  showScreen('auth');
})();
